import { getStore } from "@netlify/blobs";

const BACKUP_STORE = "habit-encrypted-backups";
const MAX_BODY_SIZE = 2_500_000;

function jsonResponse(payload, status = 200) {
  return Response.json(payload, {
    status,
    headers: {
      "Cache-Control": "no-store",
      "Content-Type": "application/json; charset=utf-8"
    }
  });
}

function validBackupId(value) {
  return /^[A-Za-z0-9_-]{32,96}$/.test(String(value || ""));
}

function validEnvelope(value) {
  return Boolean(
    value &&
      Number(value.version) === 1 &&
      /^[A-Za-z0-9_-]{16}$/.test(String(value.iv || "")) &&
      /^[A-Za-z0-9_-]+$/.test(String(value.ciphertext || "")) &&
      value.ciphertext.length <= MAX_BODY_SIZE
  );
}

async function readEnvelope(request) {
  const declaredLength = Number(request.headers.get("content-length") || 0);
  if (declaredLength > MAX_BODY_SIZE) throw new Error("Payload too large");
  const text = await request.text();
  if (!text || text.length > MAX_BODY_SIZE) throw new Error("Payload too large");
  const envelope = JSON.parse(text);
  if (!validEnvelope(envelope)) throw new Error("Invalid encrypted backup");
  return envelope;
}

export default async (request) => {
  const url = new URL(request.url);
  const id = String(url.searchParams.get("id") || "");
  if (!validBackupId(id)) return jsonResponse({ error: "Invalid backup identifier" }, 400);

  const store = getStore(BACKUP_STORE);
  const key = `backup-${id}`;

  if (request.method === "GET") {
    const backup = await store.get(key, { type: "json", consistency: "strong" });
    return backup ? jsonResponse(backup) : jsonResponse({ error: "Backup not found" }, 404);
  }

  if (request.method === "PUT") {
    try {
      const envelope = await readEnvelope(request);
      const previous = await store.get(key, { type: "json", consistency: "strong" });
      const updatedAt = new Date().toISOString();
      await store.setJSON(key, {
        ...envelope,
        createdAt: previous?.createdAt || updatedAt,
        updatedAt
      });
      return jsonResponse({ ok: true, updatedAt });
    } catch {
      return jsonResponse({ error: "Could not save encrypted backup" }, 400);
    }
  }

  if (request.method === "DELETE") {
    await store.delete(key);
    return jsonResponse({ ok: true });
  }

  return jsonResponse({ error: "Method not allowed" }, 405);
};

export const config = {
  path: "/.netlify/functions/encrypted-backup",
  rateLimit: {
    windowSize: 60,
    windowLimit: 30,
    aggregateBy: "ip"
  }
};
