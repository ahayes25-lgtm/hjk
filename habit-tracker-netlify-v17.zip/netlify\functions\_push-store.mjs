import { createHash } from "node:crypto";
import { getStore } from "@netlify/blobs";
import webpush from "web-push";

const CONFIG_STORE = "habit-push-config";
export const SUBSCRIPTION_STORE = "habit-push-subscriptions";
const CONFIG_KEY = "vapid";

export function jsonResponse(payload, status = 200) {
  return Response.json(payload, {
    status,
    headers: {
      "Cache-Control": "no-store",
      "Content-Type": "application/json; charset=utf-8"
    }
  });
}

export function subscriptionKey(endpoint) {
  return `subscription-${createHash("sha256").update(endpoint).digest("hex")}`;
}

export function validTime(value) {
  return /^([01]\d|2[0-3]):([0-5]\d)$/.test(String(value || ""));
}

export function sanitizeReminders(value) {
  if (!Array.isArray(value)) return [];
  const reminders = new Map();
  value.slice(0, 48).forEach((item) => {
    const time = String(item?.time || "");
    const days = Array.isArray(item?.days)
      ? [...new Set(item.days.map(Number).filter((day) => Number.isInteger(day) && day >= 0 && day <= 6))].sort((a, b) => a - b)
      : [];
    if (!validTime(time) || !days.length) return;
    const current = reminders.get(time) || { days: new Set(), sound: false };
    days.forEach((day) => current.days.add(day));
    current.sound = current.sound || item?.sound !== false;
    reminders.set(time, current);
  });
  return [...reminders.entries()]
    .map(([time, value]) => ({ time, days: [...value.days].sort((a, b) => a - b), sound: value.sound }))
    .sort((first, second) => first.time.localeCompare(second.time));
}

export function sanitizeTaskReminders(value) {
  if (!Array.isArray(value)) return [];
  const reminders = new Map();
  value.slice(0, 96).forEach((item) => {
    const date = String(item?.date || "");
    const time = String(item?.time || "");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !validTime(time)) return;
    const key = `${date}|${time}`;
    const current = reminders.get(key) || { date, time, sound: false };
    current.sound = current.sound || item?.sound !== false;
    reminders.set(key, current);
  });
  return [...reminders.values()].sort((first, second) => `${first.date}|${first.time}`.localeCompare(`${second.date}|${second.time}`));
}

export function validTimeZone(value) {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: value }).format();
    return true;
  } catch {
    return false;
  }
}

export function sanitizeSubscription(value) {
  if (!value || typeof value !== "object") return null;
  const endpoint = String(value.endpoint || "");
  const p256dh = String(value.keys?.p256dh || "");
  const auth = String(value.keys?.auth || "");
  if (!endpoint.startsWith("https://") || endpoint.length > 4096) return null;
  if (!p256dh || p256dh.length > 512 || !auth || auth.length > 512) return null;
  return {
    endpoint,
    expirationTime: value.expirationTime || null,
    keys: { p256dh, auth }
  };
}

export async function getVapidConfig() {
  const store = getStore(CONFIG_STORE);
  const existing = await store.get(CONFIG_KEY, { type: "json", consistency: "strong" });
  if (existing?.publicKey && existing?.privateKey && existing?.subject) return existing;

  const keys = webpush.generateVAPIDKeys();
  const siteUrl = process.env.URL?.startsWith("https://") ? process.env.URL : "https://habit-tracker.netlify.app";
  const created = {
    publicKey: keys.publicKey,
    privateKey: keys.privateKey,
    subject: siteUrl,
    createdAt: new Date().toISOString()
  };
  await store.setJSON(CONFIG_KEY, created);
  return created;
}
