(function () {
  "use strict";

  const STORE_KEY = "fa-habit-tracker-v1";
  const CLOUD_BACKUP_KEY = "fa-habit-tracker-cloud-backup-v1";
  const NOTIFICATION_DB_NAME = "fa-habit-tracker-notifications";
  const NOTIFICATION_STORE_NAME = "local-state";
  const DEFAULT_NOTIFICATION_SETTINGS = Object.freeze({
    enabled: false,
    statusTime: "08:00",
    rewardTime: "21:00",
    serverConnected: false
  });
  const DEFAULT_APPEARANCE = Object.freeze({
    theme: "system",
    textSize: "normal"
  });
  const DAY_NAMES = ["شنبه", "یکشنبه", "دوشنبه", "سه شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
  const DAY_NAMES_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];
  const JALALI_MONTH_NAMES = [
    "فروردین",
    "اردیبهشت",
    "خرداد",
    "تیر",
    "مرداد",
    "شهریور",
    "مهر",
    "آبان",
    "آذر",
    "دی",
    "بهمن",
    "اسفند"
  ];
  const ALL_DAYS = [0, 1, 2, 3, 4, 5, 6];
  const TIME_PATTERN = /^([01]\d|2[0-3]):([0-5]\d)$/;
  const app = document.getElementById("app");
  const requestedView = new URLSearchParams(window.location.search).get("view");

  let state = loadState();
  let cloudBackup = loadCloudBackupCredentials();
  let currentView = ["today", "habits", "rewards", "reports"].includes(requestedView) ? requestedView : "today";
  let habitFormType = "new";
  let editingHabitId = null;
  let editingRecovery = null;
  let editingHabitNote = null;
  let habitLibraryView = "habits";
  let reportPeriod = "week";
  let reportDayKey = todayKey();
  let reportWeekKey = startOfWeekKey(todayKey());
  let reportMonthKey = jalaliMonthKey(todayKey());
  let selectedDateKey = todayKey();
  let calendarMonth = jalaliMonthKey(selectedDateKey);
  let calendarOpen = false;
  let calendarContext = "schedule";
  let toastTimer = null;
  let habitTimerInterval = null;
  let recentlyChangedHabitId = null;
  let habitFormStep = 1;
  let editFormStep = 1;
  let completedHabitsCollapsed = true;
  let completedTasksCollapsed = true;
  let reportDetailsExpanded = false;
  let rewardFilter = "ready";
  let notificationSyncTimer = null;
  let pendingLiveNotificationUpdate = false;
  let liveStatusDirty = false;
  let notificationRequestBusy = false;
  let cloudBackupTimer = null;
  let cloudBackupBusy = false;
  let cloudBackupPending = false;
  let reminderScheduleTimer = null;
  let reorderMode = false;
  let reorderDrag = null;
  const expandedHabitIds = new Set();

  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
  }

  function toFa(value) {
    return new Intl.NumberFormat("fa-IR").format(value || 0);
  }

  function toFaDigits(value) {
    return String(value).replace(/\d/g, (digit) => "۰۱۲۳۴۵۶۷۸۹"[Number(digit)]);
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function nl2br(value) {
    return escapeHtml(value).replace(/\n/g, "<br>");
  }

  function todayKey() {
    return dateKey(new Date());
  }

  function dateKey(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  function dateFromKey(key) {
    const [y, m, d] = key.split("-").map(Number);
    return new Date(y, m - 1, d);
  }

  function addDaysKey(key, days) {
    const date = dateFromKey(key);
    date.setDate(date.getDate() + days);
    return dateKey(date);
  }

  function diffDays(fromKey, toKey) {
    const oneDay = 24 * 60 * 60 * 1000;
    return Math.round((dateFromKey(toKey) - dateFromKey(fromKey)) / oneDay);
  }

  function weekIndex(date) {
    return (date.getDay() + 1) % 7;
  }

  function startOfWeekKey(key) {
    return addDaysKey(key, -weekIndex(dateFromKey(key)));
  }

  function endOfWeekKey(key) {
    return addDaysKey(startOfWeekKey(key), 6);
  }

  function datesBetween(startKey, endKey) {
    const dates = [];
    let cursor = startKey;
    let guard = 0;
    while (cursor <= endKey && guard < 1500) {
      dates.push(cursor);
      cursor = addDaysKey(cursor, 1);
      guard += 1;
    }
    return dates;
  }

  function gregorianToJalali(gy, gm, gd) {
    const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    let jy;
    if (gy > 1600) {
      jy = 979;
      gy -= 1600;
    } else {
      jy = 0;
      gy -= 621;
    }
    const gy2 = gm > 2 ? gy + 1 : gy;
    let days =
      365 * gy +
      Math.floor((gy2 + 3) / 4) -
      Math.floor((gy2 + 99) / 100) +
      Math.floor((gy2 + 399) / 400) -
      80 +
      gd +
      gdm[gm - 1];
    jy += 33 * Math.floor(days / 12053);
    days %= 12053;
    jy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      jy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
    const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
    return [jy, jm, jd];
  }

  function jalaliToGregorian(jy, jm, jd) {
    jy += 1595;
    let days =
      -355668 +
      365 * jy +
      Math.floor(jy / 33) * 8 +
      Math.floor(((jy % 33) + 3) / 4) +
      jd +
      (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
    let gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    if (days > 36524) {
      gy += 100 * Math.floor(--days / 36524);
      days %= 36524;
      if (days >= 365) days += 1;
    }
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      gy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    let gd = days + 1;
    const monthDays = [
      0,
      31,
      ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 29 : 28,
      31,
      30,
      31,
      30,
      31,
      31,
      30,
      31,
      30,
      31
    ];
    let gm = 1;
    while (gm <= 12 && gd > monthDays[gm]) {
      gd -= monthDays[gm];
      gm += 1;
    }
    return [gy, gm, gd];
  }

  function dateKeyFromJalali(jy, jm, jd) {
    const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
    return dateKey(new Date(gy, gm - 1, gd));
  }

  function parseJalaliMonthKey(monthKey) {
    const [year, month] = monthKey.split("-").map(Number);
    return { year, month };
  }

  function shiftJalaliMonthKey(monthKey, amount) {
    const { year, month } = parseJalaliMonthKey(monthKey);
    const absolute = year * 12 + month - 1 + amount;
    const nextYear = Math.floor(absolute / 12);
    const nextMonth = absolute - nextYear * 12 + 1;
    return `${nextYear}-${String(nextMonth).padStart(2, "0")}`;
  }

  function jalaliMonthStartKey(monthKey) {
    const { year, month } = parseJalaliMonthKey(monthKey);
    return dateKeyFromJalali(year, month, 1);
  }

  function jalaliMonthDayCount(monthKey) {
    return diffDays(jalaliMonthStartKey(monthKey), jalaliMonthStartKey(shiftJalaliMonthKey(monthKey, 1)));
  }

  function formatJalaliMonth(monthKey) {
    const { year, month } = parseJalaliMonthKey(monthKey);
    return `${JALALI_MONTH_NAMES[month - 1]} ${toFaDigits(year)}`;
  }

  function jalaliParts(key) {
    const date = dateFromKey(key);
    return gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  }

  function jalaliMonthKey(key) {
    const [jy, jm] = jalaliParts(key);
    return `${jy}-${String(jm).padStart(2, "0")}`;
  }

  function formatJalali(key) {
    const [jy, jm, jd] = jalaliParts(key);
    const dayName = DAY_NAMES[weekIndex(dateFromKey(key))];
    return `${dayName} ${toFaDigits(jd)} / ${toFaDigits(jm)} / ${toFaDigits(jy)}`;
  }

  function formatJalaliShort(key) {
    const [jy, jm, jd] = jalaliParts(key);
    return `${toFaDigits(jd)} / ${toFaDigits(jm)} / ${toFaDigits(jy)}`;
  }

  function defaultState() {
    return {
      version: 8,
      createdAt: new Date().toISOString(),
      habits: [],
      tasks: {},
      activeTimer: null,
      lastBackupAt: null,
      liveStatus: {
        message: "برنامه امروز آماده است",
        kind: "status",
        updatedAt: null,
        dateKey: todayKey(),
        view: "today"
      },
      notifications: { ...DEFAULT_NOTIFICATION_SETTINGS },
      appearance: { ...DEFAULT_APPEARANCE }
    };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return defaultState();
      const parsed = JSON.parse(raw);
      return normalizeState(parsed);
    } catch (error) {
      console.warn("Could not load habit data", error);
      return defaultState();
    }
  }

  function normalizeState(data) {
    const habits = Array.isArray(data.habits) ? data.habits.map(normalizeHabit) : [];
    habits
      .map((habit, index) => ({ habit, index }))
      .sort((first, second) => (first.habit.order ?? first.index) - (second.habit.order ?? second.index) || first.index - second.index)
      .forEach(({ habit }, index) => {
        habit.order = index;
      });
    const next = {
      ...defaultState(),
      ...data,
      version: 8,
      habits,
      tasks: normalizeTasks(data.tasks),
      activeTimer: data.activeTimer && typeof data.activeTimer === "object" ? data.activeTimer : null,
      liveStatus: normalizeLiveStatus(data.liveStatus),
      notifications: normalizeNotificationSettings(data.notifications),
      appearance: normalizeAppearance(data.appearance)
    };
    return next;
  }

  function normalizeReminderMode(mode, time) {
    if (!TIME_PATTERN.test(String(time || ""))) return "off";
    return ["off", "silent", "sound"].includes(mode) ? mode : "sound";
  }

  function normalizeTasks(tasks) {
    if (!tasks || typeof tasks !== "object" || Array.isArray(tasks)) return {};
    return Object.fromEntries(
      Object.entries(tasks)
        .filter(([key, value]) => /^\d{4}-\d{2}-\d{2}$/.test(key) && Array.isArray(value))
        .map(([key, rows]) => [
          key,
          rows.slice(0, 200).map((task) => {
            const source = task && typeof task === "object" ? task : {};
            const reminderTime = TIME_PATTERN.test(String(source.reminderTime || "")) ? String(source.reminderTime) : "";
            return {
              id: String(source.id || uid()),
              text: String(source.text || "").trim().slice(0, 500),
              done: Boolean(source.done),
              createdAt: source.createdAt && !Number.isNaN(Date.parse(source.createdAt)) ? source.createdAt : null,
              reminderTime,
              reminderMode: normalizeReminderMode(source.reminderMode, reminderTime)
            };
          }).filter((task) => task.text)
        ])
        .filter(([, rows]) => rows.length)
    );
  }

  function normalizeLiveStatus(status) {
    const source = status && typeof status === "object" ? status : {};
    const updatedAt = source.updatedAt && !Number.isNaN(Date.parse(source.updatedAt)) ? source.updatedAt : null;
    return {
      message: String(source.message || "برنامه امروز آماده است").slice(0, 180),
      kind: ["habit", "task", "reward", "edit", "timer", "status"].includes(source.kind) ? source.kind : "status",
      updatedAt,
      dateKey: /^\d{4}-\d{2}-\d{2}$/.test(String(source.dateKey || "")) ? source.dateKey : todayKey(),
      view: ["today", "habits", "rewards", "reports"].includes(source.view) ? source.view : "today"
    };
  }

  function recordLiveStatus(message, kind = "status", view = "today") {
    state.liveStatus = normalizeLiveStatus({
      message,
      kind,
      updatedAt: new Date().toISOString(),
      dateKey: todayKey(),
      view
    });
    liveStatusDirty = true;
  }

  function liveStatusTime(status = state.liveStatus) {
    if (!status?.updatedAt) return "";
    return new Intl.DateTimeFormat("fa-IR", {
      hour: "2-digit",
      minute: "2-digit"
    }).format(new Date(status.updatedAt));
  }

  function normalizeNotificationSettings(settings) {
    const source = settings && typeof settings === "object" ? settings : {};
    const validTime = (value, fallback) =>
      TIME_PATTERN.test(String(value || "")) ? String(value) : fallback;
    return {
      enabled: Boolean(source.enabled),
      statusTime: validTime(source.statusTime, DEFAULT_NOTIFICATION_SETTINGS.statusTime),
      rewardTime: validTime(source.rewardTime, DEFAULT_NOTIFICATION_SETTINGS.rewardTime),
      serverConnected: Boolean(source.serverConnected)
    };
  }

  function normalizeAppearance(appearance) {
    const source = appearance && typeof appearance === "object" ? appearance : {};
    return {
      theme: ["system", "dark", "deep"].includes(source.theme) ? source.theme : "system",
      textSize: ["small", "normal", "large"].includes(source.textSize) ? source.textSize : "normal"
    };
  }

  function applyAppearance() {
    state.appearance = normalizeAppearance(state.appearance);
    const root = document.documentElement;
    if (state.appearance.theme === "system") delete root.dataset.theme;
    else root.dataset.theme = state.appearance.theme;
    root.dataset.textSize = state.appearance.textSize;

    const systemDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches;
    const dark = state.appearance.theme === "dark" || state.appearance.theme === "deep" ||
      (state.appearance.theme === "system" && systemDark);
    const color = state.appearance.theme === "deep" ? "#080d0f" : dark ? "#101619" : "#edf1f2";
    const themeMeta = document.getElementById("themeColorManual");
    if (themeMeta) themeMeta.setAttribute("content", color);
  }

  function normalizeHabit(habit) {
    const createdAt = habit.createdAt || todayKey();
    const sections = normalizeHabitSections(habit.sections);
    const reminderTime = TIME_PATTERN.test(String(habit.reminderTime || "")) ? String(habit.reminderTime) : "";
    return {
      id: habit.id || uid(),
      type: habit.type === "semi" ? "semi" : "new",
      name: habit.name || "عادت بدون نام",
      createdAt,
      duration: Number(habit.duration || 5),
      reminderTime,
      reminderMode: normalizeReminderMode(habit.reminderMode, reminderTime),
      sections,
      sectionCompletions: normalizeSectionCompletions(habit.sectionCompletions, sections),
      order: Number.isFinite(Number(habit.order)) ? Math.max(0, Math.floor(Number(habit.order))) : null,
      schedule: Array.isArray(habit.schedule) && habit.schedule.length ? habit.schedule : ALL_DAYS.slice(),
      descriptions: {
        loud: habit.descriptions?.loud || "",
        quiet: habit.descriptions?.quiet || "",
        mind: habit.descriptions?.mind || ""
      },
      impulsiveText: habit.impulsiveText || "",
      costBenefitText: habit.costBenefitText || "",
      cue: String(habit.cue || "").trim().slice(0, 500),
      noteEnabled: Boolean(habit.noteEnabled),
      notes: normalizeHabitNotes(habit.notes),
      rewardPool: Array.isArray(habit.rewardPool) ? habit.rewardPool : [],
      rewardLedger: Array.isArray(habit.rewardLedger) ? habit.rewardLedger : [],
      completions: habit.completions && typeof habit.completions === "object" ? habit.completions : {},
      graduatedAt: habit.graduatedAt || null,
      recovery: habit.recovery || {},
      durationSuggestion: habit.durationSuggestion || {}
    };
  }

  function normalizeHabitSections(sections) {
    if (!Array.isArray(sections)) return [];
    const usedIds = new Set();
    const normalized = sections
      .slice(0, 8)
      .map((section, index) => {
        const source = section && typeof section === "object" ? section : {};
        let id = String(source.id || "").trim().slice(0, 120);
        if (!id || usedIds.has(id)) id = `section-${index + 1}-${uid()}`;
        usedIds.add(id);
        const name = String(source.name || "").trim().slice(0, 80);
        return {
          id,
          name: name || `بخش ${toFa(index + 1)}`,
          time: TIME_PATTERN.test(String(source.time || "")) ? String(source.time) : "",
          reminderMode: normalizeReminderMode(source.reminderMode, source.time)
        };
      })
      .filter((section) => Boolean(section.name));
    return normalized.length >= 2 ? normalized : [];
  }

  function normalizeSectionCompletions(completions, sections) {
    if (!completions || typeof completions !== "object" || Array.isArray(completions) || !sections.length) return {};
    const validIds = new Set(sections.map((section) => section.id));
    return Object.fromEntries(
      Object.entries(completions)
        .filter(([key]) => /^\d{4}-\d{2}-\d{2}$/.test(key))
        .map(([key, values]) => {
          const source = values && typeof values === "object" && !Array.isArray(values) ? values : {};
          const completed = Object.fromEntries(
            Object.entries(source).filter(([sectionId, done]) => validIds.has(sectionId) && Boolean(done))
          );
          return Object.keys(completed).length ? [key, completed] : null;
        })
        .filter(Boolean)
    );
  }

  function normalizeHabitNotes(notes) {
    if (!notes || typeof notes !== "object" || Array.isArray(notes)) return {};
    return Object.fromEntries(
      Object.entries(notes)
        .filter(([key]) => /^\d{4}-\d{2}-\d{2}$/.test(key))
        .map(([key, note]) => {
          const source = typeof note === "string" ? { text: note } : note && typeof note === "object" ? note : {};
          const text = String(source.text || "").trim().slice(0, 4000);
          if (!text) return null;
          const createdAt =
            source.createdAt && !Number.isNaN(Date.parse(source.createdAt)) ? source.createdAt : null;
          const updatedAt =
            source.updatedAt && !Number.isNaN(Date.parse(source.updatedAt))
              ? source.updatedAt
              : createdAt;
          return [key, { text, createdAt, updatedAt }];
        })
        .filter(Boolean)
    );
  }

  function saveState() {
    localStorage.setItem(STORE_KEY, JSON.stringify(state));
    queueNotificationStateSync(liveStatusDirty);
    queueCloudBackup();
    liveStatusDirty = false;
  }

  function normalizeCloudBackupCredentials(value) {
    const source = value && typeof value === "object" ? value : {};
    const id = /^[A-Za-z0-9_-]{32,96}$/.test(String(source.id || "")) ? String(source.id) : "";
    const key = /^[A-Za-z0-9_-]{43}$/.test(String(source.key || "")) ? String(source.key) : "";
    return {
      id,
      key,
      enabled: Boolean(source.enabled && id && key),
      lastBackupAt:
        source.lastBackupAt && !Number.isNaN(Date.parse(source.lastBackupAt)) ? source.lastBackupAt : null,
      lastErrorAt:
        source.lastErrorAt && !Number.isNaN(Date.parse(source.lastErrorAt)) ? source.lastErrorAt : null
    };
  }

  function loadCloudBackupCredentials() {
    try {
      return normalizeCloudBackupCredentials(JSON.parse(localStorage.getItem(CLOUD_BACKUP_KEY) || "{}"));
    } catch {
      return normalizeCloudBackupCredentials({});
    }
  }

  function saveCloudBackupCredentials() {
    localStorage.setItem(CLOUD_BACKUP_KEY, JSON.stringify(cloudBackup));
  }

  function supportsCloudBackup() {
    return Boolean(window.isSecureContext && window.crypto?.subtle && typeof window.fetch === "function");
  }

  function uint8ArrayToBase64Url(bytes) {
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 0x8000) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    }
    return window.btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }

  function randomBase64Url(byteLength) {
    return uint8ArrayToBase64Url(crypto.getRandomValues(new Uint8Array(byteLength)));
  }

  function cloudRecoveryCode(credentials = cloudBackup) {
    return credentials.id && credentials.key ? `HT1.${credentials.id}.${credentials.key}` : "";
  }

  function parseCloudRecoveryCode(value) {
    const [version, id, key, extra] = String(value || "").trim().split(".");
    if (version !== "HT1" || extra !== undefined) return null;
    const credentials = normalizeCloudBackupCredentials({ id, key, enabled: true });
    return credentials.id && credentials.key ? credentials : null;
  }

  async function importCloudCryptoKey(keyToken) {
    return crypto.subtle.importKey(
      "raw",
      base64UrlToUint8Array(keyToken),
      { name: "AES-GCM" },
      false,
      ["encrypt", "decrypt"]
    );
  }

  async function encryptCloudBackup(payload, keyToken) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const additionalData = new TextEncoder().encode("fa-habit-tracker-backup-v1");
    const plaintext = new TextEncoder().encode(JSON.stringify(payload));
    const key = await importCloudCryptoKey(keyToken);
    const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData }, key, plaintext);
    return {
      version: 1,
      iv: uint8ArrayToBase64Url(iv),
      ciphertext: uint8ArrayToBase64Url(new Uint8Array(ciphertext))
    };
  }

  async function decryptCloudBackup(envelope, keyToken) {
    if (Number(envelope?.version) !== 1 || !envelope?.iv || !envelope?.ciphertext) {
      throw new Error("Invalid encrypted backup");
    }
    const key = await importCloudCryptoKey(keyToken);
    const additionalData = new TextEncoder().encode("fa-habit-tracker-backup-v1");
    const plaintext = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: base64UrlToUint8Array(envelope.iv),
        additionalData
      },
      key,
      base64UrlToUint8Array(envelope.ciphertext)
    );
    return JSON.parse(new TextDecoder().decode(plaintext));
  }

  async function cloudBackupRequest(id, options = {}) {
    const response = await fetch(`/.netlify/functions/encrypted-backup?id=${encodeURIComponent(id)}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      }
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "Cloud backup is unavailable");
    return payload;
  }

  function cloudBackupStatusText() {
    if (cloudBackupBusy) return "در حال ذخیره امن";
    if (!cloudBackup.id) return "راه‌اندازی نشده";
    if (!cloudBackup.enabled) return "خاموش";
    if (cloudBackup.lastErrorAt) return "نیازمند اتصال";
    if (cloudBackup.lastBackupAt) {
      return `آخرین بکاپ ${new Intl.DateTimeFormat("fa-IR", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }).format(new Date(cloudBackup.lastBackupAt))}`;
    }
    return "آماده نخستین بکاپ";
  }

  function updateCloudBackupStatus() {
    const status = document.querySelector("[data-cloud-backup-status]");
    if (status) status.textContent = cloudBackupStatusText();
  }

  async function uploadEncryptedCloudBackup(announce = false) {
    if (!cloudBackup.enabled || !cloudBackup.id || !cloudBackup.key) return false;
    if (cloudBackupBusy) {
      cloudBackupPending = true;
      return false;
    }
    if (!supportsCloudBackup() || navigator.onLine === false) {
      if (announce) showToast("برای بکاپ ابری اتصال امن اینترنت لازم است.", "error");
      return false;
    }

    cloudBackupBusy = true;
    cloudBackupPending = false;
    updateCloudBackupStatus();
    try {
      const envelope = await encryptCloudBackup(
        {
          app: "fa-habit-tracker",
          version: 1,
          exportedAt: new Date().toISOString(),
          data: state
        },
        cloudBackup.key
      );
      const result = await cloudBackupRequest(cloudBackup.id, {
        method: "PUT",
        body: JSON.stringify(envelope)
      });
      cloudBackup.lastBackupAt = result.updatedAt || new Date().toISOString();
      cloudBackup.lastErrorAt = null;
      saveCloudBackupCredentials();
      if (announce) showToast("بکاپ رمزگذاری‌شده ذخیره شد.");
      return true;
    } catch {
      cloudBackup.lastErrorAt = new Date().toISOString();
      saveCloudBackupCredentials();
      if (announce) showToast("ذخیره بکاپ ابری انجام نشد.", "error");
      return false;
    } finally {
      cloudBackupBusy = false;
      updateCloudBackupStatus();
      if (cloudBackupPending && cloudBackup.enabled) {
        clearTimeout(cloudBackupTimer);
        cloudBackupTimer = window.setTimeout(() => uploadEncryptedCloudBackup(false), 600);
      }
    }
  }

  function queueCloudBackup() {
    if (!cloudBackup.enabled || !cloudBackup.id || !cloudBackup.key) return;
    cloudBackupPending = true;
    clearTimeout(cloudBackupTimer);
    cloudBackupTimer = window.setTimeout(() => {
      uploadEncryptedCloudBackup(false);
    }, 2500);
  }

  async function restoreEncryptedCloudBackup(code) {
    const credentials = parseCloudRecoveryCode(code);
    if (!credentials) throw new Error("Invalid recovery code");
    const envelope = await cloudBackupRequest(credentials.id);
    const payload = await decryptCloudBackup(envelope, credentials.key);
    if (payload?.app !== "fa-habit-tracker" || !payload.data) throw new Error("Invalid backup payload");
    return { credentials, state: normalizeState(payload.data), updatedAt: envelope.updatedAt || null };
  }

  function notificationSnapshot() {
    const rewards = rewardOverview();
    const progress = todayProgressSummary();
    return {
      version: 2,
      updatedAt: new Date().toISOString(),
      dateKey: todayKey(),
      progress,
      liveStatus: { ...state.liveStatus },
      habits: state.habits.map((habit) => ({
        id: habit.id,
        type: habit.type,
        createdAt: habit.createdAt,
        graduatedAt: habit.graduatedAt,
        schedule: Array.isArray(habit.schedule) ? habit.schedule.slice() : ALL_DAYS.slice(),
        completions: { ...(habit.completions || {}) }
      })),
      tasks: Object.fromEntries(
        Object.entries(state.tasks || {}).map(([key, tasks]) => [
          key,
          Array.isArray(tasks) ? tasks.map((task) => ({ done: Boolean(task.done) })) : []
        ])
      ),
      rewards: {
        ready: rewards.unlocked.length,
        claimed: rewards.claimed.length,
        waiting: rewards.locked.length,
        unlockedDates: rewards.rewards.map((reward) => reward.unlockedAt).filter(Boolean),
        claimedDates: rewards.rewards.map((reward) => reward.claimedAt).filter(Boolean)
      }
    };
  }

  function nativeWidgetSnapshot() {
    const progress = todayProgressSummary();
    const rewards = rewardOverview();
    return {
      version: 1,
      updatedAt: new Date().toISOString(),
      dateKey: todayKey(),
      habitDone: progress.habitDone,
      habitTotal: progress.habitTotal,
      habitPercent: progress.habitPercent,
      taskDone: progress.taskDone,
      taskTotal: progress.taskTotal,
      rewardsReady: rewards.unlocked.length,
      lastChange: state.liveStatus?.message || "برنامه امروز آماده است",
      lastChangeAt: state.liveStatus?.updatedAt || null,
      destination: state.liveStatus?.view || "today"
    };
  }

  function syncNativeWidget() {
    try {
      window.webkit?.messageHandlers?.habitWidget?.postMessage(nativeWidgetSnapshot());
    } catch (error) {
      console.warn("Could not sync the iOS widget", error);
    }
  }

  function openNotificationDatabase() {
    return new Promise((resolve, reject) => {
      if (!("indexedDB" in window)) {
        reject(new Error("IndexedDB is unavailable"));
        return;
      }
      const request = indexedDB.open(NOTIFICATION_DB_NAME, 1);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(NOTIFICATION_STORE_NAME)) {
          database.createObjectStore(NOTIFICATION_STORE_NAME);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("Could not open notification storage"));
    });
  }

  async function writeNotificationSnapshot() {
    const database = await openNotificationDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(NOTIFICATION_STORE_NAME, "readwrite");
      transaction.objectStore(NOTIFICATION_STORE_NAME).put(notificationSnapshot(), "snapshot");
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error || new Error("Could not save notification state"));
      transaction.onabort = () => reject(transaction.error || new Error("Notification state save was aborted"));
    });
    database.close();
  }

  function queueNotificationStateSync(notifyLiveStatus = false) {
    pendingLiveNotificationUpdate = pendingLiveNotificationUpdate || notifyLiveStatus;
    clearTimeout(notificationSyncTimer);
    notificationSyncTimer = window.setTimeout(() => {
      const shouldNotify = pendingLiveNotificationUpdate;
      pendingLiveNotificationUpdate = false;
      writeNotificationSnapshot().catch(() => {});
      updateAppBadge().catch(() => {});
      syncNativeWidget();
      if (shouldNotify) updatePersistentStatusNotification().catch(() => {});
    }, 0);
  }

  function todayProgressSummary() {
    const key = todayKey();
    const habits = scheduledForDate(key);
    const habitDone = habits.filter((habit) => isDone(habit, key)).length;
    const tasks = tasksForDate(key);
    const taskDone = tasks.filter((task) => task.done).length;
    return {
      habitTotal: habits.length,
      habitDone,
      habitPercent: habits.length ? Math.round((habitDone / habits.length) * 100) : 0,
      taskTotal: tasks.length,
      taskDone,
      remaining: Math.max(0, habits.length - habitDone) + Math.max(0, tasks.length - taskDone)
    };
  }

  async function updateAppBadge() {
    if (!state.notifications.enabled || !("setAppBadge" in navigator)) return;
    const remaining = todayProgressSummary().remaining;
    if (remaining > 0) await navigator.setAppBadge(remaining);
    else if ("clearAppBadge" in navigator) await navigator.clearAppBadge();
  }

  function isIosDevice() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  }

  function isStandaloneApp() {
    return window.matchMedia?.("(display-mode: standalone)").matches || navigator.standalone === true;
  }

  function supportsPushNotifications() {
    return Boolean(
      window.isSecureContext &&
      "serviceWorker" in navigator &&
      "PushManager" in window &&
      "Notification" in window
    );
  }

  function notificationStatus() {
    if (!supportsPushNotifications()) return { label: "پشتیبانی نمی‌شود", tone: "rose" };
    if (isIosDevice() && !isStandaloneApp()) return { label: "نیازمند نصب", tone: "amber" };
    if (Notification.permission === "denied") return { label: "مسدود شده", tone: "rose" };
    if (state.notifications.enabled && Notification.permission === "granted" && !state.notifications.serverConnected) {
      return { label: "نیازمند اتصال", tone: "amber" };
    }
    if (state.notifications.enabled && Notification.permission === "granted") {
      return { label: "فعال", tone: "mint" };
    }
    return { label: "خاموش", tone: "blue" };
  }

  function base64UrlToUint8Array(value) {
    const padding = "=".repeat((4 - (value.length % 4)) % 4);
    const base64 = (value + padding).replace(/-/g, "+").replace(/_/g, "/");
    const raw = window.atob(base64);
    return Uint8Array.from(raw, (character) => character.charCodeAt(0));
  }

  async function pushServerRequest(path, options = {}) {
    const response = await fetch(`/.netlify/functions/${path}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      }
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "Push service is unavailable");
    return payload;
  }

  function pushSchedulePayload(subscription) {
    return {
      subscription: subscription.toJSON(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
      statusTime: state.notifications.statusTime,
      rewardTime: state.notifications.rewardTime,
      reminders: habitReminderSchedule(),
      taskReminders: taskReminderSchedule()
    };
  }

  function reminderModeLabel(mode) {
    if (mode === "sound") return "اعلان با صدا";
    if (mode === "silent") return "اعلان بی‌صدا";
    return "اعلان خاموش";
  }

  function isReminderActive(time, mode) {
    return TIME_PATTERN.test(String(time || "")) && ["silent", "sound"].includes(mode);
  }

  function habitReminderSchedule() {
    const grouped = new Map();
    state.habits.forEach((habit) => {
      const days = isStarterHabit(habit) ? ALL_DAYS : habit.schedule || ALL_DAYS;
      const reminders = isSectionedHabit(habit)
        ? habit.sections.map((section) => ({ time: section.time, mode: section.reminderMode }))
        : [{ time: habit.reminderTime, mode: habit.reminderMode }];
      reminders.filter((reminder) => isReminderActive(reminder.time, reminder.mode)).forEach((reminder) => {
        const entry = grouped.get(reminder.time) || { days: new Set(), sound: false };
        days.forEach((day) => entry.days.add(day));
        entry.sound = entry.sound || reminder.mode === "sound";
        grouped.set(reminder.time, entry);
      });
    });
    return [...grouped.entries()]
      .map(([time, entry]) => ({ time, days: [...entry.days].sort((first, second) => first - second), sound: entry.sound }))
      .sort((first, second) => first.time.localeCompare(second.time));
  }

  function taskReminderSchedule() {
    const grouped = new Map();
    Object.entries(state.tasks || {}).forEach(([date, tasks]) => {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date < todayKey() || !Array.isArray(tasks)) return;
      tasks.forEach((task) => {
        if (task.done || !isReminderActive(task.reminderTime, task.reminderMode)) return;
        const key = `${date}|${task.reminderTime}`;
        const entry = grouped.get(key) || { date, time: task.reminderTime, sound: false };
        entry.sound = entry.sound || task.reminderMode === "sound";
        grouped.set(key, entry);
      });
    });
    return [...grouped.values()].sort((first, second) => `${first.date}|${first.time}`.localeCompare(`${second.date}|${second.time}`));
  }

  function queueReminderScheduleSync() {
    if (!state.notifications.enabled) return;
    clearTimeout(reminderScheduleTimer);
    reminderScheduleTimer = window.setTimeout(() => {
      syncReminderSchedule().catch(() => {});
    }, 650);
  }

  async function syncReminderSchedule() {
    if (!state.notifications.enabled || !navigator.serviceWorker) return;
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      if (!subscription) throw new Error("Missing push subscription");
      await registerPushSchedule(subscription);
      if (!state.notifications.serverConnected) {
        state.notifications.serverConnected = true;
        saveState();
      }
    } catch {
      if (state.notifications.serverConnected) {
        state.notifications.serverConnected = false;
        saveState();
      }
    }
    if (currentView === "reports") render();
  }

  async function ensureServiceWorkerRegistration() {
    await navigator.serviceWorker.register("./sw.js");
    return navigator.serviceWorker.ready;
  }

  async function registerPushSchedule(subscription) {
    return pushServerRequest("push-subscription", {
      method: "POST",
      body: JSON.stringify(pushSchedulePayload(subscription))
    });
  }

  function statusNotificationBody() {
    const progress = todayProgressSummary();
    const rewards = rewardOverview();
    const change = state.liveStatus?.message ? `\n${state.liveStatus.message}` : "";
    return `${toFa(progress.habitPercent)}٪ عادت‌ها · ${toFa(progress.habitDone)} از ${toFa(progress.habitTotal)} عادت · ${toFa(progress.taskDone)} از ${toFa(progress.taskTotal)} کار · ${toFa(rewards.unlocked.length)} پاداش آماده${change}`;
  }

  function rewardNotificationBody() {
    const overview = rewardOverview();
    const key = todayKey();
    const unlockedToday = overview.rewards.filter((reward) => reward.unlockedAt === key).length;
    const claimedToday = overview.rewards.filter((reward) => reward.claimedAt === key).length;
    return `امروز ${toFa(unlockedToday)} پاداش آزاد و ${toFa(claimedToday)} پاداش گرفته شد؛ ${toFa(overview.unlocked.length)} پاداش آماده دریافت است.`;
  }

  async function updatePersistentStatusNotification() {
    if (
      !state.notifications.enabled ||
      !("Notification" in window) ||
      Notification.permission !== "granted" ||
      !("serviceWorker" in navigator)
    ) {
      return;
    }

    const registration = await ensureServiceWorkerRegistration();
    await writeNotificationSnapshot().catch(() => {});
    await registration.showNotification("وضعیت زنده امروز", {
      body: statusNotificationBody(),
      icon: "./app-icon-192.png",
      badge: "./app-icon-192.png",
      tag: "habit-tracker-live-status",
      renotify: false,
      requireInteraction: true,
      silent: true,
      dir: "rtl",
      lang: "fa",
      data: { view: state.liveStatus?.view || "today" }
    });
  }

  async function enableDailyNotifications() {
    if (notificationRequestBusy) return;
    if (!supportsPushNotifications()) {
      showToast("اعلان وب در این حالت مرورگر پشتیبانی نمی‌شود.", "error");
      return;
    }
    if (isIosDevice() && !isStandaloneApp()) {
      showToast("ابتدا برنامه را از Safari به صفحه اصلی آیفون اضافه کن.", "error");
      return;
    }

    notificationRequestBusy = true;
    try {
      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        showToast("اجازه اعلان داده نشد.", "error");
        return;
      }

      const registration = await ensureServiceWorkerRegistration();
      const config = await pushServerRequest("push-config");
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) {
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: base64UrlToUint8Array(config.publicKey)
        });
      }

      await registerPushSchedule(subscription);
      state.notifications.enabled = true;
      state.notifications.serverConnected = true;
      saveState();
      await writeNotificationSnapshot();
      await updateAppBadge();
      await updatePersistentStatusNotification();
      showToast("اعلان‌ها فعال شدند.");
    } catch (error) {
      state.notifications.enabled = false;
      state.notifications.serverConnected = false;
      saveState();
      showToast("فعال‌سازی اعلان کامل نشد؛ استقرار Netlify را بررسی کن.", "error");
    } finally {
      notificationRequestBusy = false;
      render();
    }
  }

  async function disableDailyNotifications() {
    if (notificationRequestBusy) return;
    notificationRequestBusy = true;
    try {
      const registration = await navigator.serviceWorker?.ready;
      const subscription = await registration?.pushManager?.getSubscription();
      if (subscription) {
        await pushServerRequest("push-subscription", {
          method: "DELETE",
          body: JSON.stringify({ endpoint: subscription.endpoint })
        }).catch(() => {});
        await subscription.unsubscribe();
      }
      state.notifications.enabled = false;
      state.notifications.serverConnected = false;
      saveState();
      if ("clearAppBadge" in navigator) await navigator.clearAppBadge();
      const notifications = await registration?.getNotifications?.({ tag: "habit-tracker-live-status" });
      notifications?.forEach((notification) => notification.close());
      showToast("اعلان‌ها خاموش شدند.");
    } finally {
      notificationRequestBusy = false;
      render();
    }
  }

  async function saveNotificationSchedule() {
    saveState();
    if (!state.notifications.enabled) {
      showToast("زمان اعلان‌ها ذخیره شد.");
      render();
      return;
    }
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      if (!subscription) throw new Error("Missing push subscription");
      await registerPushSchedule(subscription);
      state.notifications.serverConnected = true;
      saveState();
      showToast("زمان اعلان‌ها ذخیره شد.");
    } catch (error) {
      state.notifications.serverConnected = false;
      saveState();
      showToast("اتصال زمان‌بندی اعلان برقرار نشد.", "error");
    }
    render();
  }

  async function showNotificationPreview() {
    if (!("Notification" in window) || Notification.permission !== "granted") {
      showToast("ابتدا اعلان‌ها را فعال کن.", "error");
      return;
    }
    try {
      await ensureServiceWorkerRegistration();
      await writeNotificationSnapshot();
      await updatePersistentStatusNotification();
    } catch (error) {
      showToast("نمایش آزمایشی اعلان ممکن نشد.", "error");
    }
  }

  function findHabit(id) {
    return state.habits.find((habit) => habit.id === id);
  }

  function persistHabitOrder() {
    state.habits.forEach((habit, index) => {
      habit.order = index;
    });
  }

  function moveHabitToIndex(id, targetIndex) {
    const fromIndex = state.habits.findIndex((habit) => habit.id === id);
    if (fromIndex < 0) return false;
    const boundedIndex = Math.max(0, Math.min(state.habits.length - 1, targetIndex));
    if (fromIndex === boundedIndex) return false;
    const [habit] = state.habits.splice(fromIndex, 1);
    state.habits.splice(boundedIndex, 0, habit);
    persistHabitOrder();
    recordLiveStatus(`ترتیب «${habit.name}» تغییر کرد`, "edit", "habits");
    saveState();
    return true;
  }

  function moveHabitRelative(id, targetId, before) {
    const fromIndex = state.habits.findIndex((habit) => habit.id === id);
    const targetIndex = state.habits.findIndex((habit) => habit.id === targetId);
    if (fromIndex < 0 || targetIndex < 0 || fromIndex === targetIndex) return false;
    let nextIndex = before ? targetIndex : targetIndex + 1;
    if (fromIndex < nextIndex) nextIndex -= 1;
    return moveHabitToIndex(id, nextIndex);
  }

  function clearReorderDragMarks() {
    document.querySelectorAll("[data-reorder-card]").forEach((card) => {
      card.classList.remove("reorder-dragging", "reorder-drop-before", "reorder-drop-after");
    });
  }

  function activeTimerFor(habit, sectionId = null) {
    if (state.activeTimer?.habitId !== habit.id) return null;
    if (sectionId !== null && state.activeTimer.sectionId !== sectionId) return null;
    return state.activeTimer;
  }

  function timerRemainingSeconds(timer) {
    return Math.max(0, Math.ceil((Number(timer.endsAt) - Date.now()) / 1000));
  }

  function formatTimer(seconds) {
    const minutes = String(Math.floor(seconds / 60)).padStart(2, "0");
    const remainder = String(seconds % 60).padStart(2, "0");
    return toFaDigits(`${minutes}:${remainder}`);
  }

  function timerProgress(timer) {
    const total = Math.max(1, Number(timer.endsAt) - Number(timer.startedAt));
    return Math.max(0, Math.min(100, ((Date.now() - Number(timer.startedAt)) / total) * 100));
  }

  function captureHabitPositions() {
    const positions = new Map();
    document.querySelectorAll("[data-habit-card]").forEach((card) => {
      positions.set(card.dataset.habitCard, card.getBoundingClientRect());
    });
    return positions;
  }

  function animateHabitReorder(previousPositions) {
    if (!previousPositions?.size) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const nextFrame = window.requestAnimationFrame || ((callback) => callback());
    nextFrame(() => {
      document.querySelectorAll("[data-habit-card]").forEach((card) => {
        const previous = previousPositions.get(card.dataset.habitCard);
        if (!previous || typeof card.animate !== "function") return;
        const current = card.getBoundingClientRect();
        const deltaY = previous.top - current.top;
        if (Math.abs(deltaY) < 2) return;
        card.animate(
          [{ transform: `translateY(${deltaY}px)` }, { transform: "translateY(0)" }],
          { duration: 360, easing: "cubic-bezier(0.2, 0.8, 0.2, 1)" }
        );
      });
    });
  }

  function graduateStarterHabit(habit, key) {
    if (!isStarterHabit(habit) || completionStreak(habit, key) < 9) return false;
    habit.graduatedAt = key;
    habit.schedule = ALL_DAYS.slice();
    return true;
  }

  function openHabitNote(habit, key, mode = "complete", source = "check", sectionId = null) {
    if (!habit || !/^\d{4}-\d{2}-\d{2}$/.test(key)) return;
    editingHabitNote = {
      habitId: habit.id,
      dateKey: key,
      mode: ["edit", "complete", "section-complete"].includes(mode) ? mode : "complete",
      source: source === "timer" ? "timer" : "check",
      sectionId: sectionId && habit.sections?.some((section) => section.id === sectionId) ? sectionId : null
    };
    render();
  }

  function markHabitComplete(habit, key, options = {}) {
    if (!habit || key > todayKey() || !isScheduledOn(habit, key)) return;
    if (isSectionedHabit(habit) && !areAllSectionsDone(habit, key)) return;
    const previousPositions = captureHabitPositions();
    habit.completions ||= {};
    habit.completions[key] = true;
    completedHabitsCollapsed = true;
    expandedHabitIds.delete(habit.id);
    recentlyChangedHabitId = habit.id;
    const graduated = graduateStarterHabit(habit, key);
    const dateSuffix = key === todayKey() ? "" : ` برای ${formatJalaliShort(key)}`;
    let message = options.withNote
      ? `یادداشت ${habit.name} ثبت شد و عادت انجام شد${dateSuffix}`
      : options.viaTimer
        ? `${habit.name} با تایمر انجام شد${dateSuffix}`
        : `${habit.name} انجام شد${dateSuffix}`;
    if (graduated) message = `${habit.name} انجام شد و وارد مرحله نیمه تثبیت شد`;
    recordLiveStatus(message, "habit", "today");
    saveState();
    if (graduated) showToast("عادت وارد مرحله نیمه تثبیت شد.");
    else if (options.withNote) showToast("یادداشت ثبت شد و عادت تیک خورد.");
    else if (options.viaTimer) showToast("زمان تمام شد و عادت تیک خورد.");
    render();
    animateHabitReorder(previousPositions);
    window.setTimeout(() => {
      if (recentlyChangedHabitId === habit.id) recentlyChangedHabitId = null;
    }, 520);
  }

  function clearHabitCompletion(habit, key) {
    if (!habit || !isDone(habit, key)) return;
    const previousPositions = captureHabitPositions();
    const previousSections = { ...(habit.sectionCompletions?.[key] || {}) };
    if (key === todayKey() && state.activeTimer?.habitId === habit.id) {
      state.activeTimer = null;
      clearInterval(habitTimerInterval);
      habitTimerInterval = null;
    }
    delete habit.completions[key];
    if (isSectionedHabit(habit)) delete habit.sectionCompletions?.[key];
    expandedHabitIds.delete(habit.id);
    recentlyChangedHabitId = habit.id;
    const dateSuffix = key === todayKey() ? "" : ` برای ${formatJalaliShort(key)}`;
    recordLiveStatus(`تیک ${habit.name} برداشته شد${dateSuffix}`, "habit", "today");
    saveState();
    render();
    animateHabitReorder(previousPositions);
    const habitId = habit.id;
    showUndoToast(`تیک ${habit.name} برداشته شد.`, () => {
      const currentHabit = findHabit(habitId);
      if (!currentHabit) return;
      currentHabit.completions ||= {};
      currentHabit.completions[key] = true;
      if (Object.keys(previousSections).length) {
        currentHabit.sectionCompletions ||= {};
        currentHabit.sectionCompletions[key] = { ...previousSections };
      }
      recordLiveStatus(`${currentHabit.name} دوباره انجام‌شده ثبت شد`, "habit", "today");
      saveState();
      render();
    });
    window.setTimeout(() => {
      if (recentlyChangedHabitId === habit.id) recentlyChangedHabitId = null;
    }, 520);
  }

  function finishActiveTimer() {
    const timer = state.activeTimer;
    if (!timer) return;
    const habit = findHabit(timer.habitId);
    state.activeTimer = null;
    clearInterval(habitTimerInterval);
    habitTimerInterval = null;

    if (!habit) {
      saveState();
      render();
      return;
    }

    const key = timer.dateKey || todayKey();
    if (timer.sectionId) {
      completeHabitSection(habit, timer.sectionId, key, { viaTimer: true });
      return;
    }
    if (habit.noteEnabled) {
      editingHabitNote = {
        habitId: habit.id,
        dateKey: key,
        mode: "complete",
        source: "timer"
      };
      recordLiveStatus(`زمان ${habit.name} تمام شد؛ یادداشت در انتظار ثبت است`, "timer", "today");
      saveState();
      showToast("زمان تمام شد؛ یادداشت را ثبت کن.");
      render();
      return;
    }

    markHabitComplete(habit, key, { viaTimer: true });
  }

  function updateTimerDisplay() {
    const timer = state.activeTimer;
    if (!timer) return;
    if (timerRemainingSeconds(timer) <= 0) {
      finishActiveTimer();
      return;
    }

    const display = document.querySelector("[data-timer-display]");
    const progress = document.querySelector("[data-timer-progress]");
    if (display) display.textContent = formatTimer(timerRemainingSeconds(timer));
    if (progress) progress.style.setProperty("--timer-value", `${timerProgress(timer)}%`);
  }

  function startTimerLoop() {
    clearInterval(habitTimerInterval);
    habitTimerInterval = null;
    updateTimerDisplay();
    if (state.activeTimer) habitTimerInterval = setInterval(updateTimerDisplay, 1000);
  }

  function startHabitTimer(id, sectionId = null) {
    const habit = findHabit(id);
    const section = sectionId ? habit?.sections?.find((item) => item.id === sectionId) : null;
    if (!habit || isDone(habit, todayKey()) || (sectionId && (!section || isSectionDone(habit, sectionId, todayKey())))) return;

    if (state.activeTimer && (state.activeTimer.habitId !== habit.id || state.activeTimer.sectionId !== sectionId)) {
      const activeHabit = findHabit(state.activeTimer.habitId);
      const activeSection = activeHabit?.sections?.find((item) => item.id === state.activeTimer.sectionId);
      const activeName = activeSection ? `${activeHabit?.name || "عادت"} - ${activeSection.name}` : activeHabit?.name || "عادت دیگر";
      const replace = confirm(`تایمر «${activeName}» متوقف و تایمر جدید شروع شود؟`);
      if (!replace) return;
    }

    const startedAt = Date.now();
    state.activeTimer = {
      habitId: habit.id,
      sectionId: section?.id || null,
      dateKey: todayKey(),
      startedAt,
      endsAt: startedAt + Math.max(1, Number(habit.duration || 1)) * 60 * 1000
    };
    recordLiveStatus(`تایمر ${section ? `${habit.name} - ${section.name}` : habit.name} شروع شد`, "timer", "today");
    saveState();
    render();
  }

  function cancelHabitTimer() {
    const habit = state.activeTimer ? findHabit(state.activeTimer.habitId) : null;
    state.activeTimer = null;
    clearInterval(habitTimerInterval);
    habitTimerInterval = null;
    if (habit) recordLiveStatus(`تایمر ${habit.name} متوقف شد`, "timer", "today");
    saveState();
    showToast("تایمر متوقف شد.");
    render();
  }

  function isStarterHabit(habit) {
    return habit.type === "new" && !habit.graduatedAt;
  }

  function isDailyRewardHabit(habit) {
    return isStarterHabit(habit) || (habit.schedule || []).length === 7;
  }

  function isScheduledOn(habit, key) {
    if (key < habit.createdAt) return false;
    if (isStarterHabit(habit)) return true;
    return (habit.schedule || ALL_DAYS).includes(weekIndex(dateFromKey(key)));
  }

  function isDone(habit, key) {
    return Boolean(habit.completions?.[key]) || (isSectionedHabit(habit) && areAllSectionsDone(habit, key));
  }

  function isSectionedHabit(habit) {
    return Array.isArray(habit?.sections) && habit.sections.length >= 2;
  }

  function isSectionDone(habit, sectionId, key) {
    return Boolean(habit?.sectionCompletions?.[key]?.[sectionId]);
  }

  function completedSectionCount(habit, key) {
    if (!isSectionedHabit(habit)) return isDone(habit, key) ? 1 : 0;
    return habit.sections.filter((section) => isSectionDone(habit, section.id, key)).length;
  }

  function areAllSectionsDone(habit, key) {
    return isSectionedHabit(habit) && habit.sections.every((section) => isSectionDone(habit, section.id, key));
  }

  function setHabitSectionDone(habit, sectionId, key) {
    habit.sectionCompletions ||= {};
    habit.sectionCompletions[key] ||= {};
    habit.sectionCompletions[key][sectionId] = true;
  }

  function completeHabitSection(habit, sectionId, key, options = {}) {
    const section = habit?.sections?.find((item) => item.id === sectionId);
    if (!habit || !section || key > todayKey() || !isScheduledOn(habit, key) || isSectionDone(habit, sectionId, key)) return;
    const willCompleteHabit = habit.sections.every((item) => item.id === sectionId || isSectionDone(habit, item.id, key));
    if (willCompleteHabit && habit.noteEnabled && !options.withNote) {
      openHabitNote(habit, key, "section-complete", options.viaTimer ? "timer" : "check", sectionId);
      return;
    }

    const previousPositions = captureHabitPositions();
    setHabitSectionDone(habit, sectionId, key);
    if (areAllSectionsDone(habit, key)) {
      markHabitComplete(habit, key, options);
      return;
    }

    const dateSuffix = key === todayKey() ? "" : ` برای ${formatJalaliShort(key)}`;
    recordLiveStatus(`بخش «${section.name}» از ${habit.name} انجام شد${dateSuffix}`, "habit", "today");
    saveState();
    showToast(`${section.name} ثبت شد؛ ${toFa(completedSectionCount(habit, key))} از ${toFa(habit.sections.length)} بخش انجام شده.`);
    render();
    animateHabitReorder(previousPositions);
  }

  function clearHabitSectionCompletion(habit, sectionId, key) {
    const section = habit?.sections?.find((item) => item.id === sectionId);
    if (!habit || !section || !isSectionDone(habit, sectionId, key)) return;
    const previousPositions = captureHabitPositions();
    const wasHabitDone = isDone(habit, key);
    delete habit.sectionCompletions[key][sectionId];
    if (!Object.keys(habit.sectionCompletions[key]).length) delete habit.sectionCompletions[key];
    delete habit.completions[key];
    const dateSuffix = key === todayKey() ? "" : ` برای ${formatJalaliShort(key)}`;
    recordLiveStatus(`تیک بخش «${section.name}» برداشته شد${dateSuffix}`, "habit", "today");
    saveState();
    render();
    animateHabitReorder(previousPositions);
    const habitId = habit.id;
    showUndoToast(`تیک ${section.name} برداشته شد.`, () => {
      const currentHabit = findHabit(habitId);
      if (!currentHabit) return;
      setHabitSectionDone(currentHabit, sectionId, key);
      if (wasHabitDone) {
        currentHabit.completions ||= {};
        currentHabit.completions[key] = true;
      }
      recordLiveStatus(`بخش «${section.name}» دوباره انجام‌شده ثبت شد`, "habit", "today");
      saveState();
      render();
    });
  }

  function scheduledDatesInRange(habit, startKey, endKey) {
    return datesBetween(startKey, endKey).filter((key) => isScheduledOn(habit, key));
  }

  function periodStats(habit, dates) {
    const scheduled = dates.filter((key) => isScheduledOn(habit, key));
    const completed = scheduled.filter((key) => isDone(habit, key));
    return {
      scheduled: scheduled.length,
      completed: completed.length,
      percent: scheduled.length ? Math.round((completed.length / scheduled.length) * 100) : 0
    };
  }

  function completionStreak(habit, uptoKey = todayKey()) {
    let count = 0;
    let cursor = uptoKey;
    let guard = 0;
    while (cursor >= habit.createdAt && guard < 500) {
      if (isScheduledOn(habit, cursor)) {
        if (!isDone(habit, cursor)) {
          if (cursor === todayKey() && uptoKey === todayKey()) {
            cursor = addDaysKey(cursor, -1);
            guard += 1;
            continue;
          }
          break;
        }
        count += 1;
      }
      cursor = addDaysKey(cursor, -1);
      guard += 1;
    }
    return count;
  }

  function renderStreakDots(habit, endKey = todayKey()) {
    const days = [];
    for (let offset = 13; offset >= 0; offset -= 1) {
      const key = addDaysKey(endKey, -offset);
      const scheduled = isScheduledOn(habit, key);
      const done = scheduled && isDone(habit, key);
      days.push(
        `<span class="streak-dot ${done ? "done" : scheduled ? "missed" : "rest"}" title="${formatJalaliShort(key)}" aria-label="${formatJalaliShort(key)}: ${done ? "انجام شد" : scheduled ? "انجام نشده" : "روز استراحت"}"></span>`
      );
    }
    return `<div class="streak-strip" aria-label="عملکرد چهارده روز اخیر">${days.join("")}</div>`;
  }

  function missedScheduledStreak(habit) {
    let count = 0;
    let cursor = addDaysKey(todayKey(), -1);
    let guard = 0;
    while (cursor >= habit.createdAt && guard < 180) {
      if (isScheduledOn(habit, cursor)) {
        if (isDone(habit, cursor)) break;
        count += 1;
      }
      cursor = addDaysKey(cursor, -1);
      guard += 1;
    }
    return count;
  }

  function starterDay(habit) {
    return Math.min(9, completionStreak(habit) + 1);
  }

  function starterInstruction(habit) {
    const day = starterDay(habit);
    if (day <= 3) return habit.descriptions.loud;
    if (day <= 6) return habit.descriptions.quiet;
    return habit.descriptions.mind;
  }

  function rewardTitleFor(habit, index) {
    const titles = (habit.rewardPool || [])
      .map((reward) => String(reward?.title || "").trim())
      .filter(Boolean);
    if (titles.length) return titles[index % titles.length];
    return `پاداش ${habit.name}`;
  }

  function isGenericRewardTitle(title) {
    return /^پاداش شماره [۰-۹٠-٩0-9]+$/.test(String(title || "").trim());
  }

  function resolvedRewardTitle(habit, reward, index) {
    const currentTitle = String(reward?.title || "").trim();
    return currentTitle && !isGenericRewardTitle(currentTitle)
      ? currentTitle
      : rewardTitleFor(habit, index);
  }

  function refreshReadyRewardTitles(habit) {
    let changed = false;
    habit.rewardLedger.forEach((reward, index) => {
      if (reward.claimedAt) return;
      const title = resolvedRewardTitle(habit, reward, index);
      if (reward.title === title) return;
      reward.title = title;
      changed = true;
    });
    return changed;
  }

  function unlockReward(habit, phase, ruleLabel, periodKey) {
    if (habit.rewardLedger.some((reward) => reward.periodKey === periodKey && reward.phase === phase)) return false;
    const index = habit.rewardLedger.length;
    const title = rewardTitleFor(habit, index);
    habit.rewardLedger.push({
      id: uid(),
      title,
      phase,
      ruleLabel,
      periodKey,
      unlockedAt: todayKey(),
      claimedAt: null
    });
    recordLiveStatus(`پاداش «${title}» برای ${habit.name} آزاد شد`, "reward", "rewards");
    return true;
  }

  function updateDailyRewards(habit) {
    let changed = false;
    let phase1 = habit.rewardLedger.filter((reward) => reward.phase === "daily-3").length;
    let phase2 = habit.rewardLedger.filter((reward) => reward.phase === "daily-7").length;
    let phase3 = habit.rewardLedger.filter((reward) => reward.phase === "daily-10").length;
    const streak = completionStreak(habit);

    while (phase1 < 10 && streak >= (phase1 + 1) * 3) {
      changed = unlockReward(habit, "daily-3", "۳ روز متوالی", `daily-3-${phase1 + 1}`) || changed;
      phase1 += 1;
    }
    if (phase1 >= 10) {
      while (phase2 < 10 && streak >= 30 + (phase2 + 1) * 7) {
        changed = unlockReward(habit, "daily-7", "۷ روز متوالی", `daily-7-${phase2 + 1}`) || changed;
        phase2 += 1;
      }
    }
    if (phase1 >= 10 && phase2 >= 10) {
      while (streak >= 100 + (phase3 + 1) * 10) {
        changed = unlockReward(habit, "daily-10", "۱۰ روز متوالی", `daily-10-${phase3 + 1}`) || changed;
        phase3 += 1;
      }
    }
    return changed;
  }

  function weekStartsSince(startKey, endKey) {
    const starts = [];
    let cursor = startOfWeekKey(startKey);
    let guard = 0;
    while (cursor <= endKey && guard < 260) {
      starts.push(cursor);
      cursor = addDaysKey(cursor, 7);
      guard += 1;
    }
    return starts;
  }

  function monthKeysSince(startKey, endKey) {
    const keys = [];
    let cursor = startKey;
    let last = "";
    let guard = 0;
    while (cursor <= endKey && guard < 1500) {
      const key = jalaliMonthKey(cursor);
      if (key !== last) {
        keys.push(key);
        last = key;
      }
      cursor = addDaysKey(cursor, 1);
      guard += 1;
    }
    return keys;
  }

  function datesForJalaliMonth(monthKey, startKey, endKey) {
    return datesBetween(startKey, endKey).filter((key) => jalaliMonthKey(key) === monthKey);
  }

  function updateNonDailyRewards(habit) {
    let changed = false;
    let total = habit.rewardLedger.length;
    const today = todayKey();
    const weeks = weekStartsSince(habit.createdAt, today);

    for (const weekStart of weeks) {
      if (total >= 5) break;
      if (endOfWeekKey(weekStart) >= today) continue;
      const dates = datesBetween(weekStart, endOfWeekKey(weekStart));
      const stats = periodStats(habit, dates);
      if (stats.scheduled > 0 && stats.percent >= 70) {
        changed = unlockReward(habit, "weekly-70", "۷۰٪ برنامه هفتگی", `week-70-${weekStart}`) || changed;
        total = habit.rewardLedger.length;
      }
    }

    for (const weekStart of weeks) {
      if (total < 5 || total >= 10) break;
      if (endOfWeekKey(weekStart) >= today) continue;
      const dates = datesBetween(weekStart, endOfWeekKey(weekStart));
      const stats = periodStats(habit, dates);
      if (stats.scheduled > 0 && stats.percent === 100) {
        changed = unlockReward(habit, "weekly-100", "۱۰۰٪ برنامه هفتگی", `week-100-${weekStart}`) || changed;
        total = habit.rewardLedger.length;
      }
    }

    const currentMonth = jalaliMonthKey(today);
    for (const monthKey of monthKeysSince(habit.createdAt, today)) {
      if (total < 10) break;
      if (monthKey === currentMonth) continue;
      const dates = datesForJalaliMonth(monthKey, habit.createdAt, today);
      const stats = periodStats(habit, dates);
      if (stats.scheduled > 0 && stats.percent === 100) {
        changed = unlockReward(habit, "monthly-100", "۱۰۰٪ برنامه ماهانه", `month-100-${monthKey}`) || changed;
        total = habit.rewardLedger.length;
      }
    }

    return changed;
  }

  function refreshRewards() {
    let changed = false;
    state.habits.forEach((habit) => {
      changed = refreshReadyRewardTitles(habit) || changed;
      changed = (isDailyRewardHabit(habit) ? updateDailyRewards(habit) : updateNonDailyRewards(habit)) || changed;
    });
    if (changed) saveState();
  }

  function rewardPolicyLabel(habit) {
    if (isDailyRewardHabit(habit)) {
      const phase1 = habit.rewardLedger.filter((reward) => reward.phase === "daily-3").length;
      const phase2 = habit.rewardLedger.filter((reward) => reward.phase === "daily-7").length;
      if (phase1 < 10) return `پاداش هر ۳ روز متوالی؛ ${toFa(10 - phase1)} تا مرحله بعد`;
      if (phase2 < 10) return `پاداش هر ۷ روز متوالی؛ ${toFa(10 - phase2)} تا مرحله بعد`;
      return "پاداش هر ۱۰ روز متوالی";
    }
    const total = habit.rewardLedger.length;
    if (total < 5) return `پاداش با ۷۰٪ هفته؛ ${toFa(5 - total)} تا مرحله بعد`;
    if (total < 10) return `پاداش با ۱۰۰٪ هفته؛ ${toFa(10 - total)} تا مرحله بعد`;
    return "پاداش با ۱۰۰٪ ماه کامل";
  }

  function nextRewardProgress(habit) {
    if (isDailyRewardHabit(habit)) {
      const phase1 = habit.rewardLedger.filter((reward) => reward.phase === "daily-3").length;
      const phase2 = habit.rewardLedger.filter((reward) => reward.phase === "daily-7").length;
      const phase3 = habit.rewardLedger.filter((reward) => reward.phase === "daily-10").length;
      const streak = completionStreak(habit);
      const target = phase1 < 10
        ? (phase1 + 1) * 3
        : phase2 < 10
          ? 30 + (phase2 + 1) * 7
          : 100 + (phase3 + 1) * 10;
      const current = Math.min(streak, target);
      return {
        percent: target ? Math.round((current / target) * 100) : 0,
        label: `${toFa(current)} از ${toFa(target)} روز متوالی`,
        title: rewardTitleFor(habit, habit.rewardLedger.length)
      };
    }

    const total = habit.rewardLedger.length;
    const monthly = total >= 10;
    const stats = monthly ? currentMonthStats(habit) : currentWeekStats(habit);
    const target = total < 5 ? 70 : 100;
    return {
      percent: stats.percent,
      label: `${toFa(stats.completed)} از ${toFa(stats.scheduled)} نوبت · هدف ${toFa(target)}٪`,
      title: rewardTitleFor(habit, total)
    };
  }

  function shouldSuggestDuration(habit) {
    if (isStarterHabit(habit)) return false;
    if (diffDays(habit.graduatedAt || habit.createdAt, todayKey()) < 7) return false;
    return habit.durationSuggestion.lastWeek !== startOfWeekKey(todayKey());
  }

  function recoveryPrompt(habit) {
    const misses = missedScheduledStreak(habit);
    if (misses < 3) return null;
    const recovery = habit.recovery || {};

    if (!recovery.impulsiveDoneAt || (recovery.costDoneAt && recovery.costDoneAt >= recovery.impulsiveDoneAt)) {
      return {
        type: "impulsive",
        title: "تصور کودک تکانشی",
        text: habit.impulsiveText
      };
    }

    if (
      diffDays(recovery.impulsiveDoneAt, todayKey()) >= 5 &&
      (!recovery.costDoneAt || recovery.costDoneAt < recovery.impulsiveDoneAt)
    ) {
      return {
        type: "cost",
        title: "سود و خسارت انجام عادت",
        text: habit.costBenefitText
      };
    }

    return null;
  }

  function tasksForDate(key, create = false) {
    if (create) state.tasks[key] ||= [];
    return state.tasks[key] || [];
  }

  function scheduledForDate(key) {
    return state.habits.filter((habit) => isScheduledOn(habit, key));
  }

  function sortedHabitsForDate(key) {
    return scheduledForDate(key)
      .map((habit, index) => ({ habit, index }))
      .sort((a, b) => Number(isDone(a.habit, key)) - Number(isDone(b.habit, key)) || a.index - b.index)
      .map(({ habit }) => habit);
  }

  function completedHabitsOnDate(key) {
    return state.habits.filter((habit) => isDone(habit, key)).length;
  }

  function hasActivityOnDate(key) {
    return completedHabitsOnDate(key) > 0 || tasksForDate(key).length > 0;
  }

  function currentWeekStats(habit, key = todayKey()) {
    const start = startOfWeekKey(key);
    return periodStats(habit, datesBetween(start, endOfWeekKey(start)));
  }

  function currentMonthStats(habit, key = todayKey()) {
    const month = jalaliMonthKey(key);
    const rangeEnd = key === todayKey() ? todayKey() : jalaliMonthStartKey(shiftJalaliMonthKey(month, 1));
    const dates = datesForJalaliMonth(month, habit.createdAt, rangeEnd);
    return periodStats(habit, dates);
  }

  function reportWeekStats(habit, weekStart) {
    const periodEnd = endOfWeekKey(weekStart);
    const end = periodEnd > todayKey() ? todayKey() : periodEnd;
    return periodStats(habit, datesBetween(weekStart, end));
  }

  function reportMonthStats(habit, monthKey) {
    const start = jalaliMonthStartKey(monthKey);
    const monthEnd = addDaysKey(jalaliMonthStartKey(shiftJalaliMonthKey(monthKey, 1)), -1);
    const end = monthEnd > todayKey() ? todayKey() : monthEnd;
    return periodStats(habit, datesBetween(start, end));
  }

  function overallStatsForDates(dates) {
    let scheduled = 0;
    let completed = 0;
    state.habits.forEach((habit) => {
      const stats = periodStats(habit, dates);
      scheduled += stats.scheduled;
      completed += stats.completed;
    });
    return {
      scheduled,
      completed,
      percent: scheduled ? Math.round((completed / scheduled) * 100) : 0
    };
  }

  function activityLevel(stats) {
    if (!stats.scheduled) return "empty";
    if (!stats.percent) return "missed";
    if (stats.percent < 50) return "low";
    if (stats.percent < 80) return "medium";
    return "high";
  }

  function renderTopbar(title, eyebrow, key = todayKey(), showDate = true) {
    return `
      <header class="topbar ${showDate ? "" : "topbar-simple"}">
        <div class="title-stack">
          <p class="eyebrow">${escapeHtml(eyebrow)}</p>
          <h1>${escapeHtml(title)}</h1>
        </div>
        ${showDate ? `<div class="date-pill">${formatJalali(key)}</div>` : ""}
      </header>
    `;
  }

  function renderNav() {
    const items = [
      ["today", "امروز", "✓"],
      ["habits", "پیگیری", "▥"],
      ["add", "افزودن", "+"],
      ["rewards", "پاداش", "★"],
      ["reports", "گزارش", "▤"]
    ];
    return `
      <nav class="bottom-nav" aria-label="ناوبری">
        ${items
          .map(([view, label, icon]) => {
            const active = currentView === view || (currentView === "edit" && view === "habits");
            return `
              <button class="nav-item ${active ? "active" : ""}" data-nav="${view}" aria-label="${label}" ${active ? 'aria-current="page"' : ""}>
                <span class="nav-icon">${icon}</span>
                <span>${label}</span>
              </button>
            `;
          })
          .join("")}
      </nav>
    `;
  }

  function renderDateNavigator() {
    const isToday = selectedDateKey === todayKey();
    const isFuture = selectedDateKey > todayKey();
    return `
      <div class="date-navigation-wrap">
        <div class="date-switcher">
          <button class="date-arrow" data-date-step="-1" aria-label="روز قبل" title="روز قبل">›</button>
          <button class="date-select-button" data-open-calendar="schedule" aria-label="انتخاب تاریخ شمسی">
            <strong>${formatJalali(selectedDateKey)}</strong>
            <span>${isToday ? "تقویم شمسی" : isFuture ? "برنامه آینده" : "تاریخ انتخاب‌شده"}</span>
          </button>
          <button class="date-arrow" data-date-step="1" aria-label="روز بعد" title="روز بعد">‹</button>
        </div>
        ${!isToday ? `<button class="today-return" data-go-today="schedule">بازگشت به امروز</button>` : ""}
      </div>
    `;
  }

  function renderCalendar() {
    if (!calendarOpen) return "";
    const selectedKey = calendarContext === "report" ? reportDayKey : selectedDateKey;
    const restrictFuture = calendarContext === "report";
    const firstKey = jalaliMonthStartKey(calendarMonth);
    const leadingDays = weekIndex(dateFromKey(firstKey));
    const dayCount = jalaliMonthDayCount(calendarMonth);
    const currentMonth = jalaliMonthKey(todayKey());
    const days = [];

    for (let index = 0; index < leadingDays; index += 1) {
      days.push(`<span class="calendar-blank" aria-hidden="true"></span>`);
    }

    for (let day = 1; day <= dayCount; day += 1) {
      const key = addDaysKey(firstKey, day - 1);
      const isFuture = key > todayKey();
      const isSelected = key === selectedKey;
      const isToday = key === todayKey();
      const hasActivity = hasActivityOnDate(key);
      days.push(`
        <button
          class="calendar-day ${isSelected ? "selected" : ""} ${isToday ? "today" : ""} ${hasActivity ? "has-activity" : ""}"
          data-select-date="${key}"
          aria-label="${formatJalali(key)}"
          ${restrictFuture && isFuture ? "disabled" : ""}
        >
          <span>${toFa(day)}</span>
          ${hasActivity ? `<i aria-hidden="true"></i>` : ""}
        </button>
      `);
    }

    return `
      <div class="calendar-layer">
        <button class="calendar-backdrop" data-close-calendar aria-label="بستن تقویم"></button>
        <section class="calendar-sheet" role="dialog" aria-modal="true" aria-label="انتخاب تاریخ شمسی">
          <div class="calendar-sheet-head">
            <button class="icon-button compact" data-close-calendar aria-label="بستن تقویم">×</button>
            <strong>${calendarContext === "report" ? "تاریخ گزارش" : "انتخاب تاریخ"}</strong>
            <button class="today-calendar-button" data-go-today="${calendarContext}">امروز</button>
          </div>
          <div class="calendar-month-nav">
            <button class="date-arrow small" data-calendar-month-step="-1" aria-label="ماه قبل">›</button>
            <span>${formatJalaliMonth(calendarMonth)}</span>
            <button class="date-arrow small" data-calendar-month-step="1" aria-label="ماه بعد" ${restrictFuture && calendarMonth >= currentMonth ? "disabled" : ""}>‹</button>
          </div>
          <div class="calendar-weekdays">
            ${DAY_NAMES_SHORT.map((day) => `<span>${day}</span>`).join("")}
          </div>
          <div class="calendar-grid">${days.join("")}</div>
        </section>
      </div>
    `;
  }

  function renderHabitNoteSheet() {
    if (!editingHabitNote) return "";
    const habit = findHabit(editingHabitNote.habitId);
    if (!habit) {
      editingHabitNote = null;
      return "";
    }

    const key = editingHabitNote.dateKey;
    const existingText = habit.notes?.[key]?.text || "";
    const isEdit = editingHabitNote.mode === "edit";
    return `
      <div class="note-layer">
        <button class="note-backdrop" data-close-habit-note aria-label="بستن یادداشت"></button>
        <section class="note-sheet" role="dialog" aria-modal="true" aria-labelledby="habit-note-title">
          <div class="note-sheet-head">
            <div>
              <p class="eyebrow">${formatJalali(key)}</p>
              <h2 id="habit-note-title">${isEdit ? "ویرایش یادداشت" : escapeHtml(habit.name)}</h2>
            </div>
            <button class="icon-button compact" type="button" data-close-habit-note aria-label="بستن یادداشت">×</button>
          </div>
          <form
            id="habitNoteForm"
            data-habit="${habit.id}"
            data-date="${key}"
            data-mode="${editingHabitNote.mode}"
            data-source="${editingHabitNote.source}"
            data-section="${escapeHtml(editingHabitNote.sectionId || "")}"
          >
            <label class="field" for="habitNoteText">
              <span>یادداشت این روز</span>
              <textarea
                class="textarea note-textarea"
                id="habitNoteText"
                name="noteText"
                required
                maxlength="4000"
                placeholder="متن یادداشت"
              >${escapeHtml(existingText)}</textarea>
            </label>
            <div class="form-step-actions">
              <button class="ghost-action" type="button" data-close-habit-note>انصراف</button>
              <button class="primary-action" type="submit">${isEdit ? "ذخیره تغییرات" : "ثبت یادداشت و تکمیل"}</button>
            </div>
          </form>
        </section>
      </div>
    `;
  }

  function renderToday() {
    const isToday = selectedDateKey === todayKey();
    const isFuture = selectedDateKey > todayKey();
    const taskMode = isToday ? "today" : isFuture ? "future" : "past";
    const habits = sortedHabitsForDate(selectedDateKey);
    const pendingHabits = habits.filter((habit) => !isDone(habit, selectedDateKey));
    const completedHabits = habits.filter((habit) => isDone(habit, selectedDateKey));
    const doneCount = completedHabits.length;
    const progress = habits.length ? Math.round((doneCount / habits.length) * 100) : 0;
    const allHabitsDone = !isFuture && habits.length > 0 && pendingHabits.length === 0;
    const tasks = tasksForDate(selectedDateKey, taskMode !== "past");
    const pendingTasks = tasks.filter((task) => !task.done);
    const completedTasks = tasks.filter((task) => task.done);
    const doneTaskCount = completedTasks.length;
    const readyRewards = rewardOverview().unlocked.length;
    const liveStatus = normalizeLiveStatus(state.liveStatus);
    const liveTime = liveStatusTime(liveStatus);
    const title = isToday ? "امروز" : DAY_NAMES[weekIndex(dateFromKey(selectedDateKey))];
    return `
      ${renderTopbar(title, isToday ? "شروع هفته شنبه" : isFuture ? "برنامه آینده" : "روز انتخاب‌شده", selectedDateKey, false)}
      ${renderDateNavigator()}
      <section
        class="hero-panel ${allHabitsDone ? "complete" : ""} ${isFuture ? "future" : ""}"
        style="--progress:${progress}%"
        aria-label="${isFuture ? "برنامه‌ریزی روز آینده" : `عملکرد عادت‌ها ${progress} درصد`}"
      >
          <div class="hero-copy">
            <p class="eyebrow">${isToday ? "برنامه امروز" : isFuture ? "برنامه‌ریزی این روز" : "برنامه این روز"}</p>
            <h2>${isFuture ? `${toFa(habits.length)} عادت برنامه‌ریزی شده` : `${toFa(doneCount)} از ${toFa(habits.length)} عادت انجام شده`}</h2>
            <div class="hero-kpis">
              <span>
                <small>کارها</small>
                <strong>${isFuture ? `${toFa(tasks.length)} برنامه‌ریزی شده` : `${toFa(doneTaskCount)} از ${toFa(tasks.length)}`}</strong>
              </span>
              ${isToday ? `<span><small>پاداش</small><strong>${toFa(readyRewards)} آماده</strong></span>` : ""}
            </div>
            ${
              isToday
                ? `
                  <div class="hero-live-change ${escapeHtml(liveStatus.kind)}" role="status" aria-live="polite">
                    <i aria-hidden="true"></i>
                    <div>
                      <span>آخرین تغییر</span>
                      <strong>${escapeHtml(liveStatus.message)}</strong>
                    </div>
                    ${liveTime ? `<time datetime="${escapeHtml(liveStatus.updatedAt)}">${liveTime}</time>` : ""}
                  </div>
                `
                : ""
            }
          </div>
        <div class="hero-number" role="img" aria-label="${toFa(progress)} درصد عادت‌ها انجام شده">
          <span>
            <b>${toFa(progress)}٪</b>
            <small>عادت‌ها</small>
          </span>
        </div>
      </section>
      <section class="section">
        <div class="section-head">
          <h2>${isToday ? "عادت های امروز" : "عادت های این روز"}</h2>
          <span class="tag mint">${toFa(habits.length)} مورد</span>
        </div>
        <div class="habit-list">
          ${
            allHabitsDone
              ? `
                <div class="all-done-state" role="status">
                  <span class="all-done-icon" aria-hidden="true">✓</span>
                  <div>
                    <strong>${isToday ? "برنامه عادت های امروز کامل شد" : "همه عادت های این روز انجام شده اند"}</strong>
                    <p>${isToday ? "همه موارد برنامه ریزی شده ثبت شدند." : "نتیجه این روز به طور کامل ثبت شده است."}</p>
                  </div>
                </div>
              `
              : ""
          }
          ${pendingHabits.map((habit) => renderHabitCard(habit, true, selectedDateKey)).join("")}
          ${
            completedHabits.length
              ? `
                <button class="completion-divider" data-toggle-completed aria-expanded="${completedHabitsCollapsed ? "false" : "true"}">
                  <span>انجام شده</span>
                  <b>${toFa(completedHabits.length)}</b>
                  <i aria-hidden="true">${completedHabitsCollapsed ? "⌄" : "⌃"}</i>
                </button>
                ${completedHabitsCollapsed ? "" : completedHabits.map((habit) => renderHabitCard(habit, true, selectedDateKey)).join("")}
              `
              : ""
          }
          ${
            !habits.length
              ? `
                <div class="empty-state empty-state-action">
                  <p>برای این روز عادتی برنامه ریزی نشده.</p>
                  <button class="secondary-action" data-nav="add">افزودن عادت</button>
                </div>
              `
              : ""
          }
        </div>
      </section>
      <section class="section">
        <div class="section-head">
          <h2>${isToday ? "کارهای امروز" : isFuture ? "کارهای برنامه‌ریزی شده" : "کارهای ثبت شده"}</h2>
          <span class="tag blue">${toFa(tasks.length)} مورد</span>
        </div>
        ${
          taskMode !== "past"
            ? `
              <form class="task-form" id="taskForm">
                <div class="task-form-fields">
                  <input class="input" id="taskInput" name="task" autocomplete="off" placeholder="${isFuture ? "کار برای این روز" : "کار جدید"}" />
                  <details class="task-reminder-disclosure">
                    <summary>زمان اعلان <span>اختیاری</span></summary>
                    <div class="task-reminder-fields">
                      <label>
                        <span>ساعت</span>
                        <input class="input" type="time" name="taskReminderTime" step="60" />
                      </label>
                      <label>
                        <span>نوع اعلان</span>
                        <select class="input" name="taskReminderMode">${renderReminderModeOptions("sound")}</select>
                      </label>
                    </div>
                    <small class="field-hint">اعلان نام یا متن کار را نشان نمی‌دهد.</small>
                  </details>
                </div>
                <button class="icon-button" aria-label="افزودن کار">+</button>
              </form>
            `
            : ""
        }
        <div class="task-list task-list-spaced">
          ${pendingTasks.map((task) => renderTask(task, taskMode, selectedDateKey)).join("")}
          ${
            completedTasks.length
              ? `
                <button class="completion-divider task-completion-divider" data-toggle-completed-tasks aria-expanded="${completedTasksCollapsed ? "false" : "true"}">
                  <span>کارهای انجام شده</span>
                  <b>${toFa(completedTasks.length)}</b>
                  <i aria-hidden="true">${completedTasksCollapsed ? "⌄" : "⌃"}</i>
                </button>
                ${completedTasksCollapsed ? "" : completedTasks.map((task) => renderTask(task, taskMode, selectedDateKey)).join("")}
              `
              : ""
          }
          ${!tasks.length ? `<p class="empty-state">کاری برای این روز ثبت نشده.</p>` : ""}
        </div>
      </section>
    `;
  }

  function renderTask(task, mode = "today", key = todayKey()) {
    const canToggle = mode !== "future";
    const canDelete = mode === "today" || mode === "future";
    const activeReminder = key >= todayKey() && !task.done && isReminderActive(task.reminderTime, task.reminderMode);
    return `
      <div class="task-row ${canToggle ? "" : "read-only"} ${mode === "future" ? "future-task" : ""} ${mode === "past" ? "past-task" : ""}">
        ${
          canToggle
            ? `<button class="check ${task.done ? "done" : ""}" data-toggle-task="${task.id}" data-date="${key}" aria-label="تغییر وضعیت کار">${task.done ? "✓" : ""}</button>`
            : `<span class="check ${task.done ? "done" : ""}" aria-hidden="true">${task.done ? "✓" : ""}</span>`
        }
        <div class="task-copy">
          <p class="task-text ${task.done ? "done" : ""}">${escapeHtml(task.text)}</p>
          ${activeReminder ? `<span class="task-reminder-meta">${formatReminderTime(task.reminderTime)} · ${reminderModeLabel(task.reminderMode)}</span>` : ""}
        </div>
        ${canDelete ? `<button class="icon-button" data-delete-task="${task.id}" data-date="${key}" aria-label="حذف کار">×</button>` : `<span></span>`}
      </div>
    `;
  }

  function renderRecoveryBox(habit, prompt) {
    if (!prompt) return "";
    const field = prompt.type === "impulsive" ? "impulsiveText" : "costBenefitText";
    const savedText = habit[field] || "";
    const isEditing =
      !savedText ||
      (editingRecovery?.habitId === habit.id && editingRecovery?.type === prompt.type);

    return `
      <div class="recovery-box">
        <strong>${escapeHtml(prompt.title)}</strong>
        ${
          isEditing
            ? `
              <form class="recovery-form" data-recovery-form data-habit="${habit.id}" data-recovery-type="${prompt.type}">
                <label for="recovery-${habit.id}">متن این مرحله</label>
                <textarea class="textarea" id="recovery-${habit.id}" name="recoveryText" required placeholder="متن خودت را بنویس">${escapeHtml(savedText)}</textarea>
                <div class="inline-actions">
                  <button class="tiny-button primary-tiny" type="submit">ذخیره متن</button>
                  ${savedText ? `<button class="tiny-button" type="button" data-cancel-recovery-edit>انصراف</button>` : ""}
                </div>
              </form>
            `
            : `
              <div class="recovery-copy">${nl2br(savedText)}</div>
              <div class="inline-actions">
                <button class="tiny-button primary-tiny" data-recovery="${prompt.type}" data-habit="${habit.id}">انجام شد</button>
                <button class="tiny-button" data-edit-recovery="${prompt.type}" data-habit="${habit.id}">ویرایش متن</button>
              </div>
            `
        }
      </div>
    `;
  }

  function renderTimerPanel(habit) {
    const timer = activeTimerFor(habit);
    if (!timer) return "";
    const section = habit.sections?.find((item) => item.id === timer.sectionId);
    return `
      <div class="timer-panel" data-timer-progress style="--timer-value:${timerProgress(timer)}%" role="timer">
        <div class="timer-ring">
          <strong data-timer-display>${formatTimer(timerRemainingSeconds(timer))}</strong>
        </div>
        <div class="timer-copy">
          <strong>${section ? escapeHtml(section.name) : "در حال انجام"}</strong>
          <span>${toFa(habit.duration)} دقیقه</span>
        </div>
        <div class="timer-actions">
          <button class="timer-focus" data-toggle-focus aria-label="حالت تمرکز" title="حالت تمرکز">⛶</button>
          <button class="timer-stop" data-cancel-timer aria-label="توقف تایمر" title="توقف تایمر">×</button>
        </div>
      </div>
    `;
  }

  function formatReminderTime(time) {
    return TIME_PATTERN.test(String(time || "")) ? toFaDigits(time) : "بدون ساعت";
  }

  function currentMinuteOfDay() {
    const now = new Date();
    return now.getHours() * 60 + now.getMinutes();
  }

  function reminderIsCurrent(time) {
    if (!TIME_PATTERN.test(String(time || ""))) return false;
    const [hour, minute] = time.split(":").map(Number);
    const difference = currentMinuteOfDay() - (hour * 60 + minute);
    return difference >= 0 && difference < 60;
  }

  function habitHasCurrentReminder(habit) {
    if (isSectionedHabit(habit)) {
      return habit.sections.some((section) => isReminderActive(section.time, section.reminderMode) && reminderIsCurrent(section.time));
    }
    return isReminderActive(habit.reminderTime, habit.reminderMode) && reminderIsCurrent(habit.reminderTime);
  }

  function habitTimingSummary(habit) {
    if (isSectionedHabit(habit)) return `${toFa(habit.sections.length)} بخش با ساعت جدا`;
    if (!habit.reminderTime) return "بدون ساعت مشخص";
    return `ساعت ${formatReminderTime(habit.reminderTime)} · ${reminderModeLabel(habit.reminderMode)}`;
  }

  function renderHabitSections(habit, key, isCurrentDate, isFutureDate) {
    const completed = completedSectionCount(habit, key);
    const canToggle = key <= todayKey() && !isFutureDate;
    return `
      <div class="habit-section-progress" aria-label="${toFa(completed)} از ${toFa(habit.sections.length)} بخش انجام شده">
        <div class="habit-section-progress-head">
          <span>بخش‌ها</span>
          <strong>${toFa(completed)} از ${toFa(habit.sections.length)} بخش</strong>
        </div>
        <div class="habit-section-list">
          ${habit.sections
            .map((section) => {
              const sectionDone = isSectionDone(habit, section.id, key);
              const timer = activeTimerFor(habit, section.id);
              const due = isCurrentDate && !sectionDone && isReminderActive(section.time, section.reminderMode) && reminderIsCurrent(section.time);
              return `
                <div class="habit-section-item ${sectionDone ? "done" : ""} ${due ? "due" : ""}">
                  ${
                    canToggle
                      ? `<button class="section-check ${sectionDone ? "done" : ""}" data-toggle-habit-section="${habit.id}" data-section="${section.id}" data-date="${key}" aria-label="${sectionDone ? `برداشتن تیک ${section.name}` : `تیک ${section.name}`}">${sectionDone ? "✓" : ""}</button>`
                      : `<span class="section-check ${sectionDone ? "done" : ""}" aria-hidden="true">${sectionDone ? "✓" : ""}</span>`
                  }
                  <div class="habit-section-copy">
                    <strong>${escapeHtml(section.name)}</strong>
                    <span>${section.time ? `ساعت ${formatReminderTime(section.time)}` : "بدون ساعت"}</span>
                  </div>
                  ${
                    isCurrentDate
                      ? `<button class="section-timer ${timer ? "running" : ""}" data-start-timer="${habit.id}" data-section="${section.id}" aria-label="شروع تایمر ${section.name}" title="شروع تایمر" ${sectionDone || timer ? "disabled" : ""}>▶</button>`
                      : ""
                  }
                </div>
              `;
            })
            .join("")}
        </div>
      </div>
    `;
  }

  function renderHabitCard(habit, todayMode, key = todayKey()) {
    const done = isDone(habit, key);
    const sectioned = isSectionedHabit(habit);
    const isCurrentDate = key === todayKey();
    const isFutureDate = key > todayKey();
    const streak = completionStreak(habit, key);
    const week = currentWeekStats(habit, key);
    const month = currentMonthStats(habit, key);
    const rewardProgress = nextRewardProgress(habit);
    const rewardProgressPercent = Math.max(0, Math.min(100, rewardProgress.percent));
    const prompt = todayMode && isCurrentDate ? recoveryPrompt(habit) : null;
    const starter = isStarterHabit(habit);
    const instruction = starter && isCurrentDate ? starterInstruction(habit) : "";
    const timer = isCurrentDate ? activeTimerFor(habit) : null;
    const expanded = expandedHabitIds.has(habit.id);
    const scheduleText = starter
      ? "۹ روز متوالی"
      : (habit.schedule || ALL_DAYS).map((day) => DAY_NAMES[day]).join("، ");
    const detailText = starter
      ? isCurrentDate
        ? `${toFa(habit.duration)} دقیقه · روز ${toFa(starterDay(habit))} از ۹`
        : `${toFa(habit.duration)} دقیقه · مرحله ۹ روزه`
      : sectioned
        ? `${toFa(habit.duration)} دقیقه هر بخش · ${toFa(habit.sections.length)} بخش`
        : `${toFa(habit.duration)} دقیقه${habit.reminderTime ? ` · ساعت ${formatReminderTime(habit.reminderTime)}` : ""}`;

    return `
      <article class="habit-card ${done ? "habit-done" : ""} ${isFutureDate ? "habit-future" : ""} ${expanded ? "habit-expanded" : ""} ${recentlyChangedHabitId === habit.id ? "habit-updated" : ""} ${sectioned ? "habit-sectioned" : ""} ${isCurrentDate && !done && habitHasCurrentReminder(habit) ? "habit-due" : ""}" data-habit-card="${habit.id}">
        <div class="habit-main ${todayMode && !sectioned ? "today-habit" : "tracking-habit"}">
          ${
            todayMode && !sectioned
              ? `
                <div class="habit-controls ${isCurrentDate ? "" : "single"}">
                  ${
                    isFutureDate
                      ? `<span class="check future-check" aria-hidden="true"></span>`
                      : `<button class="check ${done ? "done" : ""}" data-toggle-habit="${habit.id}" data-date="${key}" aria-label="${done ? "برداشتن تیک عادت" : "تیک مستقیم عادت"}" title="تیک مستقیم">${done ? "✓" : ""}</button>`
                  }
                  ${
                    isCurrentDate
                      ? `<button class="timer-button ${timer ? "running" : ""}" data-start-timer="${habit.id}" aria-label="شروع تایمر ${toFa(habit.duration)} دقیقه‌ای" title="شروع تایمر" ${done || timer ? "disabled" : ""}>▶</button>`
                      : ""
                  }
                </div>
              `
              : ""
          }
          <div class="habit-content">
            <div class="habit-title-row">
              <div>
                <h3 class="habit-title">${escapeHtml(habit.name)}</h3>
                <p class="meta-line">${escapeHtml(detailText)}</p>
              </div>
              <div class="card-actions">
                <button class="icon-button compact detail-toggle ${expanded ? "expanded" : ""}" data-toggle-habit-details="${habit.id}" aria-expanded="${expanded}" aria-controls="habit-details-${escapeHtml(habit.id)}" aria-label="${expanded ? "بستن جزئیات عادت" : "نمایش جزئیات عادت"}" title="جزئیات">⌄</button>
              </div>
            </div>
            ${sectioned && todayMode ? renderHabitSections(habit, key, isCurrentDate, isFutureDate) : ""}
            ${isCurrentDate && timer ? renderTimerPanel(habit) : ""}
            <div class="habit-details" id="habit-details-${escapeHtml(habit.id)}" ${expanded ? "" : "hidden"}>
              ${renderStreakDots(habit, key)}
              <div class="habit-metrics compact-metrics" aria-label="آمار عادت">
                <span class="metric-chip mint"><span>تداوم</span><strong>${toFa(streak)}</strong></span>
                <span class="metric-chip blue"><span>هفته</span><strong>${toFa(week.percent)}٪</strong></span>
                <span class="metric-chip amber"><span>ماه</span><strong>${toFa(month.percent)}٪</strong></span>
              </div>
              <div class="habit-detail-row">
                <span>برنامه</span>
                <strong>${escapeHtml(scheduleText)}</strong>
              </div>
              <div class="habit-detail-row">
                <span>یادآوری</span>
                <strong>${escapeHtml(habitTimingSummary(habit))}</strong>
              </div>
              <div class="habit-detail-row">
                <span>الگوی پاداش</span>
                <strong>${escapeHtml(rewardPolicyLabel(habit))}</strong>
              </div>
              <div class="reward-next-progress" style="--value:${rewardProgressPercent}%">
                <div>
                  <span>پاداش بعدی</span>
                  <strong>${escapeHtml(rewardProgress.title)}</strong>
                </div>
                <small>${escapeHtml(rewardProgress.label)}</small>
                <i
                  role="progressbar"
                  aria-label="پیشرفت تا پاداش بعدی"
                  aria-valuemin="0"
                  aria-valuemax="100"
                  aria-valuenow="${rewardProgressPercent}"
                ><b></b></i>
              </div>
              ${
                habit.cue
                  ? `
                    <div class="habit-detail-row">
                      <span>محرک شروع</span>
                      <strong>${escapeHtml(habit.cue)}</strong>
                    </div>
                  `
                  : ""
              }
              ${
                habit.noteEnabled
                  ? `
                    <div class="habit-detail-row">
                      <span>یادداشت تکمیل</span>
                      <strong>اجباری</strong>
                    </div>
                  `
                  : ""
              }
              ${todayMode && isCurrentDate && instruction && !prompt && !done ? `<div class="instruction-box compact-instruction">${nl2br(instruction)}</div>` : ""}
              ${
                todayMode
                  ? ""
                  : `
                    <div class="habit-detail-actions">
                      <button class="tiny-button" data-edit-habit="${habit.id}">✎ ویرایش</button>
                      <button class="tiny-button danger-tiny" data-delete-habit="${habit.id}">× حذف</button>
                    </div>
                  `
              }
            </div>
            ${todayMode && isCurrentDate ? renderRecoveryBox(habit, prompt) : ""}
            ${
              todayMode && isCurrentDate && shouldSuggestDuration(habit) && !prompt
                ? `
                  <div class="suggestion-box">
                    <strong>افزایش زمان</strong>
                    <div>افزودن ۵ دقیقه به ${escapeHtml(habit.name)}</div>
                    <div class="inline-actions">
                      <button class="tiny-button primary-tiny" data-duration="accept" data-habit="${habit.id}">قبول</button>
                      <button class="tiny-button" data-duration="skip" data-habit="${habit.id}">فعلا نه</button>
                    </div>
                  </div>
                `
                : ""
            }
          </div>
        </div>
      </article>
    `;
  }

  function renderFormProgress(step) {
    const labels = ["مشخصات", "برنامه", "پاداش"];
    return `
      <div class="form-progress" aria-label="مراحل فرم">
        ${labels
          .map((label, index) => {
            const number = index + 1;
            return `
              <div class="form-progress-item ${step === number ? "active" : ""} ${step > number ? "complete" : ""}" data-form-progress="${number}">
                <span data-step-marker>${step > number ? "✓" : toFa(number)}</span>
                <b>${label}</b>
              </div>
            `;
          })
          .join("")}
      </div>
    `;
  }

  function renderWeekdayPicker(selectedDays = ALL_DAYS) {
    return `
      <div class="weekday-grid">
        ${ALL_DAYS.map(
          (day) => `
            <label>
              <input type="checkbox" name="weekdays" value="${day}" ${selectedDays.includes(day) ? "checked" : ""} />
              ${DAY_NAMES[day]}
            </label>
          `
        ).join("")}
      </div>
    `;
  }

  function renderNoteToggle(enabled = false, id = "noteEnabled") {
    return `
      <label class="setting-toggle-row" for="${id}">
        <span>
          <strong>یادداشت اجباری</strong>
          <small>هنگام تکمیل عادت</small>
        </span>
        <input id="${id}" type="checkbox" name="noteEnabled" role="switch" ${enabled ? "checked" : ""} />
        <i aria-hidden="true"></i>
      </label>
    `;
  }

  function renderCueField(value = "", id = "habitCue") {
    return `
      <details class="form-disclosure" ${value ? "open" : ""}>
        <summary>محرک شروع <span>اختیاری</span></summary>
        <div class="field">
          <label for="${id}">بعد از چه اتفاقی و در کجا؟</label>
          <textarea
            class="textarea"
            id="${id}"
            name="cue"
            maxlength="500"
            placeholder="مثلا بعد از مسواک، در اتاقم مدیتیشن می‌کنم"
          >${escapeHtml(value)}</textarea>
        </div>
      </details>
    `;
  }

  function renderReminderModeOptions(mode = "sound") {
    const selected = ["off", "silent", "sound"].includes(mode) ? mode : "sound";
    return `
      <option value="off" ${selected === "off" ? "selected" : ""}>خاموش</option>
      <option value="silent" ${selected === "silent" ? "selected" : ""}>اعلان بی‌صدا</option>
      <option value="sound" ${selected === "sound" ? "selected" : ""}>اعلان با صدای سیستم</option>
    `;
  }

  function renderHabitSectionEditorRow(section, index, prefix) {
    const sectionId = String(section?.id || uid());
    const sectionName = String(section?.name || `بخش ${toFa(index + 1)}`);
    const sectionTime = TIME_PATTERN.test(String(section?.time || "")) ? String(section.time) : "";
    return `
      <div class="habit-section-editor-row" data-habit-section-row>
        <input type="hidden" name="sectionId" value="${escapeHtml(sectionId)}" />
        <label>
          <span>نام بخش</span>
          <input class="input" name="sectionName" required maxlength="80" value="${escapeHtml(sectionName)}" />
        </label>
        <label>
          <span>زمان</span>
          <input class="input section-time-input" type="time" name="sectionTime" step="60" value="${escapeHtml(sectionTime)}" />
        </label>
        <button class="icon-button compact danger-icon" type="button" data-remove-habit-section aria-label="حذف بخش" title="حذف بخش">×</button>
        <label class="section-reminder-mode">
          <span>نوع اعلان</span>
          <select class="input" name="sectionReminderMode">${renderReminderModeOptions(section?.reminderMode)}</select>
        </label>
      </div>
    `;
  }

  function renderHabitTimingEditor(reminderTime = "", reminderMode = "sound", sections = [], prefix = "habit") {
    const hasSections = sections.length >= 2;
    const safeReminderTime = TIME_PATTERN.test(String(reminderTime || "")) ? String(reminderTime) : "";
    return `
      <details class="form-disclosure timing-disclosure" ${safeReminderTime || hasSections ? "open" : ""}>
        <summary>زمان و بخش‌های عادت <span>اختیاری</span></summary>
        <div class="habit-timing-editor" data-habit-timing-editor>
          <div class="field" data-single-reminder ${hasSections ? "hidden" : ""}>
            <label for="${prefix}ReminderTime">زمان یادآوری</label>
            <input class="input reminder-time-input" id="${prefix}ReminderTime" type="time" name="reminderTime" step="60" value="${escapeHtml(safeReminderTime)}" ${hasSections ? "disabled" : ""} />
            <label for="${prefix}ReminderMode">نوع اعلان</label>
            <select class="input reminder-mode-input" id="${prefix}ReminderMode" name="reminderMode" ${hasSections ? "disabled" : ""}>${renderReminderModeOptions(reminderMode)}</select>
            <small class="field-hint">اعلان نام عادت را نشان نمی‌دهد؛ صدا فقط صدای سیستم آیفون است.</small>
          </div>
          <div class="habit-section-editor" data-habit-section-editor ${hasSections ? "" : "hidden"}>
            <div class="habit-section-editor-head">
              <div>
                <strong>بخش‌های عادت</strong>
                <span>هر بخش تیک و ساعت جدا دارد.</span>
              </div>
              <button class="tiny-button" type="button" data-add-habit-section>افزودن بخش</button>
            </div>
            <div class="habit-section-editor-list" data-habit-section-list>
              ${hasSections ? sections.map((section, index) => renderHabitSectionEditorRow(section, index, prefix)).join("") : ""}
            </div>
            <button class="danger-link section-mode-reset" type="button" data-disable-habit-sections>بازگشت به یک عادت</button>
          </div>
          <button class="secondary-action section-mode-enable" type="button" data-enable-habit-sections ${hasSections ? "hidden" : ""}>تقسیم این عادت به چند بخش</button>
        </div>
      </details>
    `;
  }

  function timingFromForm(data) {
    const ids = data.getAll("sectionId").map((value) => String(value || "").trim());
    const names = data.getAll("sectionName").map((value) => String(value || "").trim());
    const times = data.getAll("sectionTime").map((value) => String(value || "").trim());
    const modes = data.getAll("sectionReminderMode").map((value) => String(value || "").trim());
    const sections = names.map((name, index) => ({
      id: ids[index] || uid(),
      name,
      time: times[index] || "",
      reminderMode: normalizeReminderMode(modes[index], times[index])
    }));
    const hasSectionRows = sections.length > 0;
    if (hasSectionRows && sections.length < 2) return { error: "برای عادت چندبخشی حداقل دو بخش لازم است." };
    if (sections.some((section) => !section.name)) return { error: "نام همه بخش‌ها را وارد کن." };
    if (sections.some((section) => section.time && !TIME_PATTERN.test(section.time))) {
      return { error: "زمان یکی از بخش‌ها درست نیست." };
    }
    const reminderTime = String(data.get("reminderTime") || "").trim();
    const reminderMode = String(data.get("reminderMode") || "").trim();
    if (reminderTime && !TIME_PATTERN.test(reminderTime)) return { error: "زمان یادآوری درست نیست." };
    return {
      reminderTime: hasSectionRows ? "" : reminderTime,
      reminderMode: hasSectionRows ? "off" : normalizeReminderMode(reminderMode, reminderTime),
      sections: hasSectionRows ? sections : []
    };
  }

  function renderFormReview(name = "—", duration = "—", scheduleCount = 0, rewardCount = 0, noteEnabled = false) {
    return `
      <div class="form-review" aria-live="polite">
        <div><span>نام</span><strong data-review-name>${escapeHtml(name)}</strong></div>
        <div><span>زمان</span><strong data-review-duration>${escapeHtml(String(duration))}</strong></div>
        <div><span>روزها</span><strong data-review-schedule>${toFa(scheduleCount)}</strong></div>
        <div><span>پاداش‌ها</span><strong data-review-rewards>${toFa(rewardCount)}</strong></div>
        <div><span>یادداشت</span><strong data-review-note>${noteEnabled ? "اجباری" : "خاموش"}</strong></div>
      </div>
    `;
  }

  function renderAdd() {
    const isNew = habitFormType === "new";
    return `
      ${renderTopbar("افزودن عادت", isNew ? "عادت جدید" : "عادت نیمه تثبیت")}
      <section class="form-panel">
        <div class="segmented">
          <button class="segment ${isNew ? "active" : ""}" data-form-type="new">عادت جدید</button>
          <button class="segment ${!isNew ? "active" : ""}" data-form-type="semi">نیمه تثبیت</button>
        </div>
        ${renderFormProgress(habitFormStep)}
        <form id="habitForm" data-form-flow="add" data-habit-type="${habitFormType}" data-current-step="${habitFormStep}">
          <section class="form-step" data-form-panel="1" ${habitFormStep === 1 ? "" : "hidden"}>
            <div class="form-step-head" tabindex="-1">
              <span>مرحله ۱ از ۳</span>
              <h2>مشخصات اصلی</h2>
            </div>
            <div class="field">
              <label for="habitName">نام عادت</label>
              <input class="input" id="habitName" name="name" required placeholder="مثلا مدیتیشن" />
            </div>
            <div class="field">
              <label for="duration">مدت هر بار انجام</label>
              <div class="number-field">
                <input class="input" id="duration" name="duration" type="number" min="1" step="1" value="${isNew ? "5" : "15"}" required />
                <span>دقیقه</span>
              </div>
            </div>
            ${renderNoteToggle(false)}
            <div class="form-step-actions single-action">
              <button class="primary-action" type="button" data-form-next="add">ادامه</button>
            </div>
          </section>

          <section class="form-step" data-form-panel="2" ${habitFormStep === 2 ? "" : "hidden"}>
            <div class="form-step-head" tabindex="-1">
              <span>مرحله ۲ از ۳</span>
              <h2>${isNew ? "متن‌های شروع" : "برنامه هفتگی"}</h2>
            </div>
            ${
              isNew
                ? `
                  <div class="field">
                    <label for="descLoud">روز ۱ تا ۳</label>
                    <textarea class="textarea" id="descLoud" name="descLoud" placeholder="متن با صدای بلند گفتن"></textarea>
                  </div>
                  <div class="field">
                    <label for="descQuiet">روز ۴ تا ۶</label>
                    <textarea class="textarea" id="descQuiet" name="descQuiet" placeholder="متن با صدای آهسته گفتن"></textarea>
                  </div>
                  <div class="field">
                    <label for="descMind">روز ۷ تا ۹</label>
                    <textarea class="textarea" id="descMind" name="descMind" placeholder="متن گفتن در ذهن"></textarea>
                  </div>
                `
                : `
                  <div class="field">
                    <span>روزهای هفته</span>
                    ${renderWeekdayPicker()}
                  </div>
                `
            }
            ${renderCueField()}
            ${renderHabitTimingEditor("", "sound", [], "habit")}
            <div class="form-step-actions">
              <button class="ghost-action" type="button" data-form-prev="add">قبلی</button>
              <button class="primary-action" type="button" data-form-next="add">ادامه</button>
            </div>
          </section>

          <section class="form-step" data-form-panel="3" ${habitFormStep === 3 ? "" : "hidden"}>
            <div class="form-step-head" tabindex="-1">
              <span>مرحله ۳ از ۳</span>
              <h2>پاداش و مرور</h2>
            </div>
            <div class="field">
              <label for="rewards">پاداش‌ها</label>
              <textarea class="textarea" id="rewards" name="rewards" placeholder="هر خط یک پاداش"></textarea>
            </div>
            ${renderFormReview("—", `${isNew ? 5 : 15} دقیقه`, isNew ? 9 : 7, 0, false)}
            <div class="form-step-actions">
              <button class="ghost-action" type="button" data-form-prev="add">قبلی</button>
              <button class="primary-action" type="submit">ثبت عادت</button>
            </div>
          </section>
        </form>
      </section>
    `;
  }

  function renderEdit() {
    const habit = findHabit(editingHabitId);
    if (!habit) {
      currentView = "habits";
      return renderHabits();
    }
    const rewardText = (habit.rewardPool || []).map((reward) => reward.title).join("\n");
    const rewardCount = (habit.rewardPool || []).length;

    return `
      ${renderTopbar("ویرایش عادت", habit.name)}
      <section class="form-panel">
        ${renderFormProgress(editFormStep)}
        <form id="editHabitForm" data-habit="${habit.id}" data-form-flow="edit" data-habit-type="${habit.type}" data-current-step="${editFormStep}">
          <section class="form-step" data-form-panel="1" ${editFormStep === 1 ? "" : "hidden"}>
            <div class="form-step-head" tabindex="-1">
              <span>مرحله ۱ از ۳</span>
              <h2>مشخصات اصلی</h2>
            </div>
            <div class="field">
              <label for="editHabitName">نام عادت</label>
              <input class="input" id="editHabitName" name="name" required value="${escapeHtml(habit.name)}" />
            </div>
            <div class="field">
              <label for="editDuration">مدت هر بار انجام</label>
              <div class="number-field">
                <input class="input" id="editDuration" name="duration" type="number" min="1" step="1" required value="${Number(habit.duration || 1)}" />
                <span>دقیقه</span>
              </div>
            </div>
            ${renderNoteToggle(habit.noteEnabled, "editNoteEnabled")}
            <div class="form-step-actions">
              <button class="ghost-action" type="button" data-nav="habits">انصراف</button>
              <button class="primary-action" type="button" data-form-next="edit">ادامه</button>
            </div>
          </section>

          <section class="form-step" data-form-panel="2" ${editFormStep === 2 ? "" : "hidden"}>
            <div class="form-step-head" tabindex="-1">
              <span>مرحله ۲ از ۳</span>
              <h2>${habit.type === "new" ? "متن‌های شروع" : "برنامه هفتگی"}</h2>
            </div>
            ${
              habit.type === "new"
                ? `
                  <div class="field">
                    <label for="editDescLoud">روز ۱ تا ۳</label>
                    <textarea class="textarea" id="editDescLoud" name="descLoud">${escapeHtml(habit.descriptions.loud)}</textarea>
                  </div>
                  <div class="field">
                    <label for="editDescQuiet">روز ۴ تا ۶</label>
                    <textarea class="textarea" id="editDescQuiet" name="descQuiet">${escapeHtml(habit.descriptions.quiet)}</textarea>
                  </div>
                  <div class="field">
                    <label for="editDescMind">روز ۷ تا ۹</label>
                    <textarea class="textarea" id="editDescMind" name="descMind">${escapeHtml(habit.descriptions.mind)}</textarea>
                  </div>
                `
                : `
                  <div class="field">
                    <span>روزهای هفته</span>
                    ${renderWeekdayPicker(habit.schedule || ALL_DAYS)}
                  </div>
                `
            }
            ${renderCueField(habit.cue, "editHabitCue")}
            ${renderHabitTimingEditor(habit.reminderTime, habit.reminderMode, habit.sections, "editHabit")}
            <div class="form-step-actions">
              <button class="ghost-action" type="button" data-form-prev="edit">قبلی</button>
              <button class="primary-action" type="button" data-form-next="edit">ادامه</button>
            </div>
          </section>

          <section class="form-step" data-form-panel="3" ${editFormStep === 3 ? "" : "hidden"}>
            <div class="form-step-head" tabindex="-1">
              <span>مرحله ۳ از ۳</span>
              <h2>پاداش و مرور</h2>
            </div>
            <div class="field">
              <label for="editRewards">پاداش‌ها</label>
              <textarea class="textarea" id="editRewards" name="rewards" placeholder="هر خط یک پاداش">${escapeHtml(rewardText)}</textarea>
            </div>
            ${renderFormReview(
              habit.name,
              `${toFa(habit.duration)} دقیقه`,
              habit.type === "new" ? 9 : (habit.schedule || []).length,
              rewardCount,
              habit.noteEnabled
            )}
            <div class="form-step-actions">
              <button class="ghost-action" type="button" data-form-prev="edit">قبلی</button>
              <button class="primary-action" type="submit">ذخیره تغییرات</button>
            </div>
          </section>
        </form>
      </section>
    `;
  }

  function habitNoteEntries() {
    return state.habits
      .flatMap((habit) =>
        Object.entries(habit.notes || {}).map(([dateKey, note]) => ({
          habitId: habit.id,
          habitName: habit.name,
          dateKey,
          text: note.text,
          createdAt: note.createdAt,
          updatedAt: note.updatedAt
        }))
      )
      .sort(
        (first, second) =>
          second.dateKey.localeCompare(first.dateKey) ||
          String(second.updatedAt || "").localeCompare(String(first.updatedAt || ""))
      );
  }

  function recoveryArchiveEntries() {
    return state.habits
      .flatMap((habit) => {
        const entries = [];
        if (String(habit.impulsiveText || "").trim()) {
          entries.push({
            habitId: habit.id,
            habitName: habit.name,
            kind: "impulsive",
            title: "تصور کودک تکانشی",
            text: habit.impulsiveText,
            completedAt: habit.recovery?.impulsiveDoneAt || null,
            sortKey: habit.recovery?.impulsiveDoneAt || habit.createdAt
          });
        }
        if (String(habit.costBenefitText || "").trim()) {
          entries.push({
            habitId: habit.id,
            habitName: habit.name,
            kind: "cost",
            title: "سود و خسارت",
            text: habit.costBenefitText,
            completedAt: habit.recovery?.costDoneAt || null,
            sortKey: habit.recovery?.costDoneAt || habit.createdAt
          });
        }
        return entries;
      })
      .sort((first, second) => String(second.sortKey || "").localeCompare(String(first.sortKey || "")));
  }

  function renderHabitNoteArchiveCard(entry) {
    return `
      <article class="journal-card">
        <div class="journal-card-head">
          <div>
            <span class="journal-kind">یادداشت عادت</span>
            <h3>${escapeHtml(entry.habitName)}</h3>
          </div>
          <time datetime="${entry.dateKey}">${formatJalaliShort(entry.dateKey)}</time>
        </div>
        <div class="journal-text">${nl2br(entry.text)}</div>
        <div class="journal-actions">
          <button
            class="icon-button compact"
            data-edit-habit-note="${entry.habitId}"
            data-date="${entry.dateKey}"
            aria-label="ویرایش یادداشت"
            title="ویرایش یادداشت"
          >✎</button>
          <button
            class="icon-button compact danger-icon"
            data-delete-habit-note="${entry.habitId}"
            data-date="${entry.dateKey}"
            aria-label="حذف یادداشت"
            title="حذف یادداشت"
          >×</button>
        </div>
      </article>
    `;
  }

  function renderRecoveryArchiveCard(entry) {
    return `
      <article class="journal-card recovery-journal ${entry.kind}">
        <div class="journal-card-head">
          <div>
            <span class="journal-kind">${escapeHtml(entry.title)}</span>
            <h3>${escapeHtml(entry.habitName)}</h3>
          </div>
          ${
            entry.completedAt
              ? `<time datetime="${entry.completedAt}">${formatJalaliShort(entry.completedAt)}</time>`
              : `<span class="journal-status">ثبت شده</span>`
          }
        </div>
        <div class="journal-text">${nl2br(entry.text)}</div>
      </article>
    `;
  }

  function renderReorderHabitCard(habit, index) {
    const first = index === 0;
    const last = index === state.habits.length - 1;
    return `
      <article class="reorder-habit-card" data-habit-card="${habit.id}" data-reorder-card="${habit.id}">
        <button class="reorder-handle" type="button" data-reorder-handle="${habit.id}" aria-label="گرفتن و جابه‌جا کردن ${escapeHtml(habit.name)}" title="بکش و جابه‌جا کن">⠿</button>
        <div class="reorder-habit-copy">
          <strong>${escapeHtml(habit.name)}</strong>
          <span>${escapeHtml(habitTimingSummary(habit))}</span>
        </div>
        <div class="reorder-actions" aria-label="تغییر ترتیب ${escapeHtml(habit.name)}">
          <button class="icon-button compact" type="button" data-reorder-move="first" data-habit="${habit.id}" aria-label="بردن به ابتدای فهرست" title="ابتدای فهرست" ${first ? "disabled" : ""}>⇈</button>
          <button class="icon-button compact" type="button" data-reorder-move="up" data-habit="${habit.id}" aria-label="یک پله بالاتر" title="یک پله بالاتر" ${first ? "disabled" : ""}>↑</button>
          <button class="icon-button compact" type="button" data-reorder-move="down" data-habit="${habit.id}" aria-label="یک پله پایین‌تر" title="یک پله پایین‌تر" ${last ? "disabled" : ""}>↓</button>
          <button class="icon-button compact" type="button" data-reorder-move="last" data-habit="${habit.id}" aria-label="بردن به انتهای فهرست" title="انتهای فهرست" ${last ? "disabled" : ""}>⇊</button>
        </div>
      </article>
    `;
  }

  function renderHabits() {
    const notes = habitNoteEntries();
    const recoveryEntries = recoveryArchiveEntries();
    const viewMeta = {
      habits: { title: "همه عادت ها", count: state.habits.length, unit: "عادت", tone: "mint" },
      notes: { title: "یادداشت های ثبت شده", count: notes.length, unit: "یادداشت", tone: "blue" },
      recovery: { title: "متن های بازگشت", count: recoveryEntries.length, unit: "متن", tone: "rose" }
    };
    const selectedMeta = viewMeta[habitLibraryView] || viewMeta.habits;
    let content = "";

    if (habitLibraryView === "notes") {
      content = notes.length
        ? `<div class="journal-list">${notes.map(renderHabitNoteArchiveCard).join("")}</div>`
        : `<p class="empty-state">هنوز یادداشتی ثبت نشده.</p>`;
    } else if (habitLibraryView === "recovery") {
      content = recoveryEntries.length
        ? `<div class="journal-list">${recoveryEntries.map(renderRecoveryArchiveCard).join("")}</div>`
        : `<p class="empty-state">هنوز متن بازگشتی ثبت نشده.</p>`;
    } else {
      content = `
        <div class="habit-list ${reorderMode ? "reorder-list" : ""}">
          ${
            state.habits.length
              ? reorderMode
                ? state.habits.map((habit, index) => renderReorderHabitCard(habit, index)).join("")
                : state.habits.map((habit) => renderHabitCard(habit, false)).join("")
              : `
                <div class="empty-state empty-state-action">
                  <p>هنوز عادتی ثبت نشده.</p>
                  <button class="secondary-action" data-nav="add">افزودن عادت</button>
                </div>
              `
          }
        </div>
      `;
    }

    return `
      ${renderTopbar("پیگیری", "عادت ها و نوشته ها")}
      <div class="segmented tracking-switch" aria-label="بخش پیگیری">
        <button class="segment ${habitLibraryView === "habits" ? "active" : ""}" data-habit-library-view="habits">عادت ها</button>
        <button class="segment ${habitLibraryView === "notes" ? "active" : ""}" data-habit-library-view="notes">یادداشت ها</button>
        <button class="segment ${habitLibraryView === "recovery" ? "active" : ""}" data-habit-library-view="recovery">بازگشت ها</button>
      </div>
      <section class="section">
        <div class="section-head">
          <h2>${selectedMeta.title}</h2>
          <div class="section-head-actions">
            <span class="tag ${selectedMeta.tone}">${toFa(selectedMeta.count)} ${selectedMeta.unit}</span>
            ${
              habitLibraryView === "habits" && state.habits.length > 1
                ? `<button class="tiny-button reorder-toggle ${reorderMode ? "active" : ""}" type="button" data-toggle-reorder aria-pressed="${reorderMode}">${reorderMode ? "پایان چینش" : "مرتب‌سازی"}</button>`
                : ""
            }
          </div>
        </div>
        ${content}
      </section>
    `;
  }

  function rewardOverview() {
    const rewards = state.habits.flatMap((habit) =>
      habit.rewardLedger.map((reward, index) => ({
        ...reward,
        title: resolvedRewardTitle(habit, reward, index),
        habitName: habit.name,
        habitId: habit.id
      }))
    );
    const unlocked = rewards.filter((reward) => !reward.claimedAt);
    const claimed = rewards.filter((reward) => reward.claimedAt);
    const locked = state.habits.flatMap((habit) =>
      (habit.rewardPool || []).slice(habit.rewardLedger.length).map((reward, index) => ({
        id: `locked-${habit.id}-${index}`,
        title: reward.title,
        habitName: habit.name,
        habitId: habit.id,
        ruleLabel: rewardPolicyLabel(habit),
        locked: true
      }))
    );
    return { rewards, unlocked, claimed, locked };
  }

  function renderRewards() {
    const { unlocked, claimed, locked } = rewardOverview();
    const filterConfig = {
      ready: { title: "آماده دریافت", rows: unlocked, empty: "پاداش آماده‌ای وجود ندارد." },
      claimed: { title: "گرفته شده", rows: claimed, empty: "هنوز پاداشی گرفته نشده." },
      locked: { title: "در انتظار", rows: locked, empty: "پاداش ثبت‌شده‌ای در انتظار نیست." }
    };
    const selected = filterConfig[rewardFilter] || filterConfig.ready;

    return `
      ${renderTopbar("پاداش ها", `${toFa(unlocked.length)} پاداش نگرفته`)}
      <section class="reward-overview" aria-label="خلاصه پاداش‌ها">
        <div class="reward-overview-main">
          <span>آماده دریافت</span>
          <strong>${toFa(unlocked.length)}</strong>
        </div>
        <div><span>گرفته شده</span><strong>${toFa(claimed.length)}</strong></div>
        <div><span>در انتظار</span><strong>${toFa(locked.length)}</strong></div>
      </section>
      <div class="segmented reward-switch" aria-label="وضعیت پاداش">
        <button class="segment ${rewardFilter === "ready" ? "active" : ""}" data-reward-filter="ready">آماده</button>
        <button class="segment ${rewardFilter === "claimed" ? "active" : ""}" data-reward-filter="claimed">گرفته‌شده</button>
        <button class="segment ${rewardFilter === "locked" ? "active" : ""}" data-reward-filter="locked">در انتظار</button>
      </div>
      <section class="section">
        <div class="section-head">
          <h2>${selected.title}</h2>
          <span class="tag ${rewardFilter === "claimed" ? "mint" : rewardFilter === "locked" ? "blue" : "amber"}">${toFa(selected.rows.length)}</span>
        </div>
        <div class="reward-list">
          ${
            selected.rows.length
              ? selected.rows.map(renderRewardCard).join("")
              : `
                <div class="empty-state empty-state-action">
                  <p>${selected.empty}</p>
                  <button class="ghost-action" data-nav="habits">مدیریت عادت‌ها</button>
                </div>
              `
          }
        </div>
      </section>
    `;
  }

  function renderRewardCard(reward) {
    const stateLabel = reward.locked ? "هنوز آزاد نشده" : reward.claimedAt ? "گرفته شده" : "آزاد شده";
    const stateClass = reward.locked ? "blue" : reward.claimedAt ? "mint" : "amber";
    return `
      <article class="reward-card ${reward.claimedAt ? "claimed" : ""} ${reward.locked ? "locked" : ""}">
        <h3>${escapeHtml(reward.title)}</h3>
        <p class="meta-line">${escapeHtml(reward.habitName)} · ${escapeHtml(reward.ruleLabel)}${reward.unlockedAt ? ` · ${formatJalaliShort(reward.unlockedAt)}` : ""}</p>
        <div class="reward-state">
          <span class="tag ${stateClass}">${stateLabel}</span>
          ${
            reward.locked
              ? `<span class="reward-lock" aria-hidden="true">◷</span>`
              : reward.claimedAt
              ? `<span class="meta-line">${formatJalaliShort(reward.claimedAt)}</span>`
              : `<button class="secondary-action" data-claim-reward="${reward.id}" data-habit="${reward.habitId}">گرفتم</button>`
          }
        </div>
      </article>
    `;
  }

  function renderNotificationSettings() {
    const status = notificationStatus();
    const permission = "Notification" in window ? Notification.permission : "default";
    const enabled = state.notifications.enabled && permission === "granted";
    const reminderCount = habitReminderSchedule().length;
    const taskReminderCount = taskReminderSchedule().length;
    let stateText = "وضعیت زنده و اعلان‌های روزانه خاموش است.";
    if (!supportsPushNotifications()) stateText = "اعلان وب در این مرورگر در دسترس نیست.";
    else if (isIosDevice() && !isStandaloneApp()) stateText = "برای فعال‌سازی، برنامه باید روی صفحه اصلی آیفون نصب باشد.";
    else if (permission === "denied") stateText = "اجازه اعلان از تنظیمات آیفون مسدود شده است.";
    else if (enabled && state.notifications.serverConnected) stateText = "وضعیت با هر تغییر به‌روز می‌شود؛ نتیجه پاداش نیز روزانه می‌آید.";
    else if (enabled) stateText = "اعلان فعال است؛ اتصال زمان‌بندی نیاز به بررسی دارد.";

    return `
      <section class="notification-panel" aria-labelledby="notification-title">
        <div class="section-head">
          <h2 id="notification-title">وضعیت روی آیفون</h2>
          <span class="tag ${status.tone}">${status.label}</span>
        </div>
        <div class="notification-control">
          <div>
            <strong>اعلان وضعیت زنده</strong>
            <span>${stateText}</span>
          </div>
          <button
            class="notification-toggle ${enabled ? "active" : ""}"
            type="button"
            role="switch"
            aria-checked="${enabled}"
            aria-label="${enabled ? "خاموش کردن اعلان‌ها" : "فعال کردن اعلان‌ها"}"
            data-toggle-notifications
            ${notificationRequestBusy ? "disabled" : ""}
          >
            <i aria-hidden="true"></i>
          </button>
        </div>
        <div class="habit-reminder-privacy">
          <span class="storage-status-icon" aria-hidden="true">◷</span>
          <div>
            <strong>یادآور عادت‌ها و کارها</strong>
            <span>${reminderCount || taskReminderCount ? `${toFa(reminderCount)} ساعت عادت و ${toFa(taskReminderCount)} یادآور کار فعال است؛ هیچ نامی در اعلان نمی‌آید.` : "زمان هر عادت را از ویرایش آن و زمان کار را هنگام افزودن کار وارد کن."}</span>
          </div>
        </div>
        <form class="notification-form" id="notificationSettingsForm">
          <label>
            <span>وضعیت عادت‌ها و کارها</span>
            <input class="time-input" type="time" name="statusTime" value="${state.notifications.statusTime}" step="900" required />
          </label>
          <label>
            <span>نتیجه پاداش‌ها</span>
            <input class="time-input" type="time" name="rewardTime" value="${state.notifications.rewardTime}" step="900" required />
          </label>
          <div class="notification-actions">
            <button class="secondary-action" type="submit">ذخیره زمان‌ها</button>
            <button class="ghost-action" type="button" data-test-notification>به‌روزرسانی اعلان</button>
          </div>
        </form>
      </section>
    `;
  }

  function renderDataSafetyPanel(taskCount) {
    const hasCloudBackup = Boolean(cloudBackup.id && cloudBackup.key);
    const recoveryCode = cloudRecoveryCode();
    const cloudTone = !supportsCloudBackup()
      ? "rose"
      : cloudBackup.lastErrorAt
        ? "amber"
        : cloudBackup.enabled
          ? "mint"
          : "blue";
    const cloudLabel = !supportsCloudBackup()
      ? "در دسترس نیست"
      : cloudBackup.enabled
        ? "خودکار"
        : "خاموش";

    return `
      <section class="backup-panel">
        <div class="section-head">
          <h2>امنیت داده</h2>
          <span class="tag ${cloudTone}">${cloudLabel}</span>
        </div>
        <div class="storage-status" role="status">
          <span class="storage-status-icon" aria-hidden="true">✓</span>
          <div>
            <strong>ذخیره محلی فعال است</strong>
            <span>${toFa(state.habits.length)} عادت و ${toFa(taskCount)} کار ذخیره شده</span>
          </div>
        </div>
        <div class="quick-actions">
          <button class="secondary-action" data-export>خروجی گرفتن</button>
          <button class="ghost-action" data-import-trigger>بازیابی فایل</button>
        </div>
        <input class="hidden" id="importFile" type="file" accept="application/json,.json" />

        <div class="settings-divider"></div>
        <div class="cloud-backup-control">
          <div>
            <strong>بکاپ رمزگذاری‌شده</strong>
            <span data-cloud-backup-status role="status" aria-live="polite">${cloudBackupStatusText()}</span>
          </div>
          <button
            class="notification-toggle ${cloudBackup.enabled ? "active" : ""}"
            type="button"
            role="switch"
            aria-checked="${cloudBackup.enabled}"
            aria-label="${cloudBackup.enabled ? "خاموش کردن بکاپ خودکار" : "فعال کردن بکاپ خودکار"}"
            data-toggle-cloud-backup
            ${!supportsCloudBackup() || cloudBackupBusy ? "disabled" : ""}
          ><i aria-hidden="true"></i></button>
        </div>
        ${
          hasCloudBackup
            ? `
              <div class="recovery-key-block">
                <label for="cloudRecoveryCode">کد بازیابی</label>
                <textarea class="recovery-code" id="cloudRecoveryCode" readonly dir="ltr" spellcheck="false" autocapitalize="off">${recoveryCode}</textarea>
                <strong class="recovery-warning">کد را خارج از برنامه نگه دار.</strong>
                <div class="cloud-actions">
                  <button class="tiny-button" type="button" data-copy-recovery>کپی</button>
                  <button class="tiny-button" type="button" data-export-recovery>ذخیره در Files</button>
                  <button class="tiny-button primary-tiny" type="button" data-backup-now ${cloudBackupBusy ? "disabled" : ""}>بکاپ حالا</button>
                </div>
              </div>
            `
            : ""
        }
        <details class="settings-disclosure">
          <summary>بازیابی با کد</summary>
          <form class="cloud-restore-form" id="cloudRestoreForm">
            <label for="restoreRecoveryCode">کد بازیابی</label>
            <textarea class="textarea recovery-code-input" id="restoreRecoveryCode" name="recoveryCode" required dir="ltr" autocomplete="off" spellcheck="false" autocapitalize="off"></textarea>
            <button class="secondary-action" type="submit">دریافت و بازیابی</button>
          </form>
          ${
            hasCloudBackup
              ? `<button class="danger-link" type="button" data-delete-cloud-backup>حذف بکاپ ابری</button>`
              : ""
          }
        </details>
      </section>
    `;
  }

  function renderAppearanceSettings() {
    const appearance = normalizeAppearance(state.appearance);
    return `
      <section class="appearance-panel">
        <div class="section-head">
          <h2>ظاهر برنامه</h2>
          <span class="tag blue">شخصی</span>
        </div>
        <div class="appearance-group">
          <span>حالت نمایش</span>
          <div class="segmented appearance-switch" role="group" aria-label="حالت نمایش">
            ${[
              ["system", "سیستم"],
              ["dark", "تیره"],
              ["deep", "خیلی تیره"]
            ]
              .map(
                ([value, label]) => `
                  <button
                    type="button"
                    class="segment ${appearance.theme === value ? "active" : ""}"
                    data-appearance-theme="${value}"
                    aria-pressed="${appearance.theme === value}"
                  >${label}</button>
                `
              )
              .join("")}
          </div>
        </div>
        <div class="appearance-group">
          <span>اندازه متن</span>
          <div class="segmented appearance-switch" role="group" aria-label="اندازه متن">
            ${[
              ["small", "کوچک"],
              ["normal", "معمولی"],
              ["large", "بزرگ"]
            ]
              .map(
                ([value, label]) => `
                  <button
                    type="button"
                    class="segment ${appearance.textSize === value ? "active" : ""}"
                    data-appearance-text="${value}"
                    aria-pressed="${appearance.textSize === value}"
                  >${label}</button>
                `
              )
              .join("")}
          </div>
        </div>
      </section>
    `;
  }

  function renderReportNavigator() {
    const currentWeek = startOfWeekKey(todayKey());
    const currentMonth = jalaliMonthKey(todayKey());
    let label;
    let current;
    let unitLabel;
    let center;

    if (reportPeriod === "day") {
      label = formatJalali(reportDayKey);
      current = reportDayKey === todayKey();
      unitLabel = "روز";
      center = `
        <button class="date-select-button" data-open-calendar="report" aria-label="انتخاب تاریخ گزارش">
          <strong>${label}</strong>
          <span>گزارش روزانه</span>
        </button>
      `;
    } else if (reportPeriod === "month") {
      label = formatJalaliMonth(reportMonthKey);
      current = reportMonthKey === currentMonth;
      unitLabel = "ماه";
      center = `<div class="date-select-button static"><strong>${label}</strong><span>گزارش ماهانه</span></div>`;
    } else {
      label = `${formatJalaliShort(reportWeekKey)} تا ${formatJalaliShort(endOfWeekKey(reportWeekKey))}`;
      current = reportWeekKey === currentWeek;
      unitLabel = "هفته";
      center = `<div class="date-select-button static"><strong>${label}</strong><span>شنبه تا جمعه</span></div>`;
    }

    return `
      <div class="report-navigation-wrap">
        <div class="date-switcher report-date-switcher">
          <button class="date-arrow" data-report-step="-1" aria-label="${unitLabel} قبل" title="${unitLabel} قبل">›</button>
          ${center}
          <button class="date-arrow" data-report-step="1" aria-label="${unitLabel} بعد" title="${unitLabel} بعد" ${current ? "disabled" : ""}>‹</button>
        </div>
        ${!current ? `<button class="today-return" data-report-current>بازگشت به بازه جاری</button>` : ""}
      </div>
    `;
  }

  function renderReports() {
    const habits = state.habits;
    const today = todayKey();
    const day = reportDayKey;
    const weekStart = reportWeekKey;
    const weekEnd = endOfWeekKey(weekStart);
    const month = reportMonthKey;
    const weekRangeEnd = weekEnd > today ? today : weekEnd;
    const weekDates = datesBetween(weekStart, weekRangeEnd);
    const monthStart = jalaliMonthStartKey(month);
    const monthEnd = addDaysKey(jalaliMonthStartKey(shiftJalaliMonthKey(month, 1)), -1);
    const monthRangeEnd = monthEnd > today ? today : monthEnd;
    const monthDates = datesBetween(monthStart, monthRangeEnd);
    const previousMonth = shiftJalaliMonthKey(month, -1);
    const previousMonthStart = jalaliMonthStartKey(previousMonth);
    const previousMonthLength = jalaliMonthDayCount(previousMonth);
    const comparisonMonthLength = Math.min(monthDates.length, previousMonthLength);
    const previousMonthDates = comparisonMonthLength
      ? datesBetween(previousMonthStart, addDaysKey(previousMonthStart, comparisonMonthLength - 1))
      : [];
    const periodConfig = {
      day: {
        title: day === today ? "گزارش امروز" : `گزارش ${DAY_NAMES[weekIndex(dateFromKey(day))]}`,
        date: formatJalaliShort(day),
        dates: [day],
        previousDates: [addDaysKey(day, -1)],
        rows: habits
          .filter((habit) => isScheduledOn(habit, day))
          .map((habit) => {
            const completed = isDone(habit, day) ? 1 : 0;
            return {
              name: habit.name,
              percent: completed ? 100 : 0,
              completed,
              scheduled: 1,
              label: completed ? "انجام شده" : "انجام نشده"
            };
          })
      },
      week: {
        title: "گزارش هفتگی",
        date: `${formatJalaliShort(weekStart)} تا ${formatJalaliShort(weekEnd)}`,
        dates: weekDates,
        previousDates: weekDates.map((key) => addDaysKey(key, -7)),
        rows: habits.map((habit) => {
          const stats = reportWeekStats(habit, weekStart);
          return {
            name: habit.name,
            percent: stats.percent,
            completed: stats.completed,
            scheduled: stats.scheduled,
            label: `${toFa(stats.completed)} از ${toFa(stats.scheduled)} نوبت`
          };
        })
      },
      month: {
        title: "گزارش ماه شمسی",
        date: formatJalaliMonth(month),
        dates: monthDates,
        previousDates: previousMonthDates,
        rows: habits.map((habit) => {
          const stats = reportMonthStats(habit, month);
          return {
            name: habit.name,
            percent: stats.percent,
            completed: stats.completed,
            scheduled: stats.scheduled,
            label: `${toFa(stats.completed)} از ${toFa(stats.scheduled)} نوبت`
          };
        })
      }
    };
    const selected = periodConfig[reportPeriod] || periodConfig.week;
    const selectedStats = overallStatsForDates(selected.dates);
    const previousStats = overallStatsForDates(selected.previousDates);
    const totalCompleted = selectedStats.completed;
    const totalScheduled = selectedStats.scheduled;
    const overallPercent = selectedStats.percent;
    const comparisonDelta = overallPercent - previousStats.percent;
    const comparisonClass = !previousStats.scheduled ? "neutral" : comparisonDelta > 0 ? "positive" : comparisonDelta < 0 ? "negative" : "neutral";
    const comparisonLabel = !previousStats.scheduled
      ? "بدون داده قبلی"
      : comparisonDelta > 0
        ? `${toFa(Math.abs(comparisonDelta))}٪ بهتر`
        : comparisonDelta < 0
          ? `${toFa(Math.abs(comparisonDelta))}٪ کمتر`
          : "بدون تغییر";
    const trendDates = reportPeriod === "day" ? datesBetween(addDaysKey(day, -6), day) : selected.dates;
    const trendPoints = trendDates.map((key) => ({ key, ...overallStatsForDates([key]) }));
    const trendAverage = overallStatsForDates(trendDates).percent;
    const heatmapEnd = selected.dates[selected.dates.length - 1] || day;
    const heatmapStart = addDaysKey(startOfWeekKey(heatmapEnd), -28);
    const heatmapDates = datesBetween(heatmapStart, endOfWeekKey(heatmapEnd));
    const taskCount = Object.values(state.tasks).reduce((sum, tasks) => sum + (Array.isArray(tasks) ? tasks.length : 0), 0);

    return `
      ${renderTopbar("گزارش ها", "روزانه، هفتگی و ماهانه")}
      <div class="segmented report-switch" aria-label="بازه گزارش">
        <button class="segment ${reportPeriod === "day" ? "active" : ""}" data-report-period="day">روزانه</button>
        <button class="segment ${reportPeriod === "week" ? "active" : ""}" data-report-period="week">هفتگی</button>
        <button class="segment ${reportPeriod === "month" ? "active" : ""}" data-report-period="month">ماهانه</button>
      </div>
      ${renderReportNavigator()}
      <section class="section report-section">
        <div class="section-head">
          <h2>${selected.title}</h2>
          <span class="period-date">${selected.date}</span>
        </div>
        ${
          totalScheduled
            ? `
              <div class="report-summary" style="--value:${overallPercent}%">
                <div class="report-summary-score">
                  <span>عملکرد این بازه</span>
                  <strong>${toFa(overallPercent)}٪</strong>
                </div>
                <div class="report-summary-counts">
                  <span><b>${toFa(totalCompleted)}</b> انجام شده</span>
                  <span><b>${toFa(totalScheduled)}</b> برنامه ریزی شده</span>
                </div>
                <div class="report-comparison ${comparisonClass}">
                  <span>بازه قبل ${toFa(previousStats.percent)}٪</span>
                  <strong>${comparisonLabel}</strong>
                </div>
                <div class="report-summary-track" aria-hidden="true"><span></span></div>
              </div>
            `
            : ""
        }
        ${
          habits.length
            ? `
              <button class="report-details-toggle" data-toggle-report-details aria-expanded="${reportDetailsExpanded}">
                <span>جزئیات گزارش</span>
                <b>${toFa(selected.rows.length)} عادت</b>
                <i aria-hidden="true">${reportDetailsExpanded ? "⌃" : "⌄"}</i>
              </button>
            `
            : ""
        }
        ${
          habits.length && reportDetailsExpanded
            ? `
              <div class="report-visuals">
                <section class="report-visual-block" aria-labelledby="trend-title">
                  <div class="report-visual-head">
                    <h3 id="trend-title">روند انجام</h3>
                    <span>میانگین ${toFa(trendAverage)}٪</span>
                  </div>
                  <div class="trend-chart" style="--point-count:${Math.max(1, trendPoints.length)}">
                    ${trendPoints
                      .map(
                        (point) => `
                          <span class="trend-column ${activityLevel(point)}" role="img" aria-label="${formatJalaliShort(point.key)}، ${toFa(point.percent)} درصد">
                            <i style="--point:${point.scheduled ? Math.max(7, point.percent) : 4}%"></i>
                          </span>
                        `
                      )
                      .join("")}
                  </div>
                  <div class="trend-axis">
                    <span>${trendPoints.length ? formatJalaliShort(trendPoints[0].key) : ""}</span>
                    <span>${trendPoints.length ? formatJalaliShort(trendPoints[trendPoints.length - 1].key) : ""}</span>
                  </div>
                </section>
                <section class="report-visual-block" aria-labelledby="heatmap-title">
                  <div class="report-visual-head">
                    <h3 id="heatmap-title">نقشه پنج هفته</h3>
                    <span>شدت فعالیت روزانه</span>
                  </div>
                  <div class="heatmap-weekdays" aria-hidden="true">
                    ${DAY_NAMES_SHORT.map((name) => `<span>${name}</span>`).join("")}
                  </div>
                  <div class="activity-heatmap">
                    ${heatmapDates
                      .map((key) => {
                        if (key > heatmapEnd) return `<span class="heat-cell future" aria-hidden="true"></span>`;
                        const stats = overallStatsForDates([key]);
                        return `<span class="heat-cell ${activityLevel(stats)}" role="img" aria-label="${formatJalaliShort(key)}، ${toFa(stats.percent)} درصد"></span>`;
                      })
                      .join("")}
                  </div>
                  <div class="heatmap-legend" aria-hidden="true">
                    <span>کم</span><i class="missed"></i><i class="low"></i><i class="medium"></i><i class="high"></i><span>زیاد</span>
                  </div>
                </section>
              </div>
            `
            : ""
        }
        ${
          reportDetailsExpanded
            ? `
              <div class="report-list">
                ${selected.rows.length ? selected.rows.map(renderReportRow).join("") : `<p class="empty-state">برای این بازه گزارشی وجود ندارد.</p>`}
              </div>
            `
            : ""
        }
        ${!habits.length ? `<p class="empty-state">برای این بازه گزارشی وجود ندارد.</p>` : ""}
      </section>
      ${renderDataSafetyPanel(taskCount)}
      ${renderAppearanceSettings()}
      ${renderNotificationSettings()}
    `;
  }

  function renderReportRow(row) {
    return `
      <article class="report-row">
        <div class="report-top">
          <h3>${escapeHtml(row.name)}</h3>
          <span class="tag ${row.percent >= 70 ? "mint" : row.percent ? "amber" : "rose"}">${toFa(row.percent)}٪</span>
        </div>
        <div class="progress-line" style="--value:${Math.max(0, Math.min(100, row.percent))}%"><span></span></div>
        <p class="meta-line">${escapeHtml(row.label)}</p>
      </article>
    `;
  }

  function render() {
    refreshRewards();
    const views = {
      today: renderToday,
      add: renderAdd,
      edit: renderEdit,
      habits: renderHabits,
      rewards: renderRewards,
      reports: renderReports
    };
    app.innerHTML = `${(views[currentView] || renderToday)()}${renderCalendar()}${renderHabitNoteSheet()}${renderNav()}`;
    attachFormHandlers();
    if (editingHabitNote?.source !== "timer") {
      document.getElementById("habitNoteText")?.focus({ preventScroll: true });
    }
    startTimerLoop();
    queueNotificationStateSync();
  }

  function updateFormReview(form) {
    const name = String(form.querySelector('[name="name"]')?.value || "—").trim() || "—";
    const duration = Math.max(1, Number(form.querySelector('[name="duration"]')?.value || 1));
    const rewardCount = String(form.querySelector('[name="rewards"]')?.value || "")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean).length;
    const scheduleCount = form.dataset.habitType === "new"
      ? 9
      : form.querySelectorAll('[name="weekdays"]:checked').length;
    const noteEnabled = Boolean(form.querySelector('[name="noteEnabled"]')?.checked);

    const values = {
      "[data-review-name]": name,
      "[data-review-duration]": `${toFa(duration)} دقیقه`,
      "[data-review-schedule]": toFa(scheduleCount),
      "[data-review-rewards]": toFa(rewardCount),
      "[data-review-note]": noteEnabled ? "اجباری" : "خاموش"
    };
    Object.entries(values).forEach(([selector, value]) => {
      const element = form.querySelector(selector);
      if (element) element.textContent = value;
    });
  }

  function createHabitSectionEditorRow(index) {
    const row = document.createElement("div");
    row.className = "habit-section-editor-row";
    row.dataset.habitSectionRow = "";
    row.innerHTML = renderHabitSectionEditorRow({ id: uid(), name: `بخش ${toFa(index + 1)}`, time: "", reminderMode: "sound" }, index, "dynamic")
      .replace(/^\s*<div[^>]*>/, "")
      .replace(/<\/div>\s*$/, "");
    return row;
  }

  function setHabitSectionMode(form, enabled) {
    const editor = form?.querySelector("[data-habit-timing-editor]");
    if (!editor) return;
    const singleReminder = editor.querySelector("[data-single-reminder]");
    const sectionEditor = editor.querySelector("[data-habit-section-editor]");
    const sectionList = editor.querySelector("[data-habit-section-list]");
    const enableButton = editor.querySelector("[data-enable-habit-sections]");
    if (!singleReminder || !sectionEditor || !sectionList || !enableButton) return;

    if (enabled) {
      if (!sectionList.querySelector("[data-habit-section-row]")) {
        sectionList.append(createHabitSectionEditorRow(0), createHabitSectionEditorRow(1));
      }
      singleReminder.hidden = true;
      sectionEditor.hidden = false;
      enableButton.hidden = true;
      singleReminder.querySelectorAll("input, select").forEach((field) => field.setAttribute("disabled", ""));
      sectionList.querySelectorAll("input, select").forEach((field) => field.removeAttribute("disabled"));
      return;
    }

    sectionList.replaceChildren();
    singleReminder.hidden = false;
      sectionEditor.hidden = true;
      enableButton.hidden = false;
      singleReminder.querySelectorAll("input, select").forEach((field) => field.removeAttribute("disabled"));
  }

  function addHabitSectionRow(button) {
    const editor = button.closest("[data-habit-timing-editor]");
    const list = editor?.querySelector("[data-habit-section-list]");
    if (!list) return;
    const rows = list.querySelectorAll("[data-habit-section-row]");
    if (rows.length >= 8) {
      showToast("برای هر عادت حداکثر ۸ بخش می‌توانی بسازی.", "error");
      return;
    }
    list.append(createHabitSectionEditorRow(rows.length));
    list.lastElementChild?.querySelector('[name="sectionName"]')?.focus();
  }

  function validateFormStep(form, step) {
    const panel = form.querySelector(`[data-form-panel="${step}"]`);
    if (!panel) return false;
    const requiredFields = panel.querySelectorAll("input[required], textarea[required], select[required]");
    for (const field of requiredFields) {
      if (!field.checkValidity()) {
        field.reportValidity();
        field.focus();
        return false;
      }
    }
    if (step === 2 && form.dataset.habitType === "semi" && !form.querySelector('[name="weekdays"]:checked')) {
      showToast("حداقل یک روز هفته را انتخاب کن.", "error");
      return false;
    }
    return true;
  }

  function moveFormStep(flow, direction) {
    const form = document.querySelector(`[data-form-flow="${flow}"]`);
    if (!form) return;
    const current = Number(form.dataset.currentStep || 1);
    if (direction > 0 && !validateFormStep(form, current)) return;
    const next = Math.max(1, Math.min(3, current + direction));
    if (flow === "add") habitFormStep = next;
    if (flow === "edit") editFormStep = next;
    form.dataset.currentStep = String(next);

    form.querySelectorAll("[data-form-panel]").forEach((panel) => {
      panel.hidden = Number(panel.dataset.formPanel) !== next;
    });
    form.closest(".form-panel")?.querySelectorAll("[data-form-progress]").forEach((item) => {
      const itemStep = Number(item.dataset.formProgress);
      item.classList.toggle("active", itemStep === next);
      item.classList.toggle("complete", itemStep < next);
      const marker = item.querySelector("[data-step-marker]");
      if (marker) marker.textContent = itemStep < next ? "✓" : toFa(itemStep);
    });
    if (next === 3) updateFormReview(form);
    form.querySelector(`[data-form-panel="${next}"] .form-step-head`)?.focus();
  }

  function attachFormHandlers() {
    const taskForm = document.getElementById("taskForm");
    if (taskForm) {
      taskForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const input = document.getElementById("taskInput");
        const text = input.value.trim();
        if (!text || selectedDateKey < todayKey()) return;
        const data = new FormData(taskForm);
        const reminderTime = String(data.get("taskReminderTime") || "").trim();
        const reminderMode = normalizeReminderMode(String(data.get("taskReminderMode") || "").trim(), reminderTime);
        if (reminderTime && !TIME_PATTERN.test(reminderTime)) {
          showToast("زمان اعلان کار درست نیست.", "error");
          return;
        }
        tasksForDate(selectedDateKey, true).push({
          id: uid(),
          text,
          done: false,
          createdAt: new Date().toISOString(),
          reminderTime,
          reminderMode
        });
        recordLiveStatus(
          selectedDateKey === todayKey() ? `کار «${text}» به امروز اضافه شد` : `کار «${text}» برای ${formatJalaliShort(selectedDateKey)} ثبت شد`,
          "task",
          "today"
        );
        saveState();
        queueReminderScheduleSync();
        input.value = "";
        render();
      });
    }

    const habitForm = document.getElementById("habitForm");
    if (habitForm) {
      habitForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const data = new FormData(habitForm);
        const name = String(data.get("name") || "").trim();
        const duration = Math.max(1, Number(data.get("duration") || 5));
        const rewards = String(data.get("rewards") || "")
          .split("\n")
          .map((line) => line.trim())
          .filter(Boolean)
          .map((title) => ({ id: uid(), title }));
        if (!name) return;
        const timing = timingFromForm(data);
        if (timing.error) {
          showToast(timing.error, "error");
          return;
        }

        const habit = normalizeHabit({
          id: uid(),
          type: habitFormType,
          name,
          createdAt: todayKey(),
          duration,
          reminderTime: timing.reminderTime,
          reminderMode: timing.reminderMode,
          sections: timing.sections,
          order: state.habits.length,
          schedule:
            habitFormType === "new"
              ? ALL_DAYS.slice()
              : Array.from(data.getAll("weekdays")).map(Number).sort((a, b) => a - b),
          descriptions: {
            loud: String(data.get("descLoud") || "").trim(),
            quiet: String(data.get("descQuiet") || "").trim(),
            mind: String(data.get("descMind") || "").trim()
          },
          cue: String(data.get("cue") || "").trim(),
          noteEnabled: data.get("noteEnabled") === "on",
          rewardPool: rewards
        });

        if (!habit.schedule.length) {
          showToast("حداقل یک روز هفته را انتخاب کن.", "error");
          return;
        }

        state.habits.push(habit);
        recordLiveStatus(`عادت «${habit.name}» ساخته شد`, "edit", "habits");
        saveState();
        queueReminderScheduleSync();
        habitFormStep = 1;
        currentView = "today";
        selectedDateKey = todayKey();
        calendarMonth = jalaliMonthKey(selectedDateKey);
        showToast("عادت ثبت شد.");
        render();
      });
    }

    const editHabitForm = document.getElementById("editHabitForm");
    if (editHabitForm) {
      editHabitForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const habit = findHabit(editHabitForm.dataset.habit);
        if (!habit) return;
        const data = new FormData(editHabitForm);
        const name = String(data.get("name") || "").trim();
        const duration = Math.max(1, Number(data.get("duration") || 1));
        const rewardTitles = String(data.get("rewards") || "")
          .split("\n")
          .map((line) => line.trim())
          .filter(Boolean);
        const schedule = Array.from(data.getAll("weekdays")).map(Number).sort((a, b) => a - b);
        const timing = timingFromForm(data);

        if (!name) return;
        if (timing.error) {
          showToast(timing.error, "error");
          return;
        }
        if (habit.type === "semi" && !schedule.length) {
          showToast("حداقل یک روز هفته را انتخاب کن.", "error");
          return;
        }

        const previousName = habit.name;
        habit.name = name;
        habit.duration = duration;
        habit.reminderTime = timing.reminderTime;
        habit.reminderMode = timing.reminderMode;
        habit.sections = timing.sections;
        habit.sectionCompletions = normalizeSectionCompletions(habit.sectionCompletions, habit.sections);
        habit.cue = String(data.get("cue") || "").trim().slice(0, 500);
        habit.noteEnabled = data.get("noteEnabled") === "on";
        if (habit.type === "new") {
          habit.descriptions = {
            loud: String(data.get("descLoud") || "").trim(),
            quiet: String(data.get("descQuiet") || "").trim(),
            mind: String(data.get("descMind") || "").trim()
          };
        }
        if (habit.type === "semi") habit.schedule = schedule;

        habit.rewardPool = rewardTitles.map((title, index) => ({
          id: habit.rewardPool[index]?.id || uid(),
          title
        }));
        habit.rewardLedger.forEach((reward, index) => {
          if (!reward.claimedAt) reward.title = rewardTitleFor(habit, index);
        });

        recordLiveStatus(
          previousName === habit.name
            ? `تنظیمات «${habit.name}» به‌روز شد`
            : `نام «${previousName}» به «${habit.name}» تغییر کرد`,
          "edit",
          "habits"
        );
        saveState();
        queueReminderScheduleSync();
        editingHabitId = null;
        editFormStep = 1;
        currentView = "habits";
        showToast("تغییرات ذخیره شد.");
        render();
      });
    }

    const habitNoteForm = document.getElementById("habitNoteForm");
    if (habitNoteForm) {
      habitNoteForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const habit = findHabit(habitNoteForm.dataset.habit);
        const key = habitNoteForm.dataset.date;
        const text = String(new FormData(habitNoteForm).get("noteText") || "").trim();
        if (!habit || !text) {
          showToast("متن یادداشت لازم است.", "error");
          document.getElementById("habitNoteText")?.focus();
          return;
        }

        habit.notes ||= {};
        const previousNote = habit.notes[key];
        const now = new Date().toISOString();
        habit.notes[key] = {
          text: text.slice(0, 4000),
          createdAt: previousNote?.createdAt || now,
          updatedAt: now
        };
        const mode = habitNoteForm.dataset.mode;
        const source = habitNoteForm.dataset.source;
        editingHabitNote = null;

        if (mode === "section-complete") {
          completeHabitSection(habit, habitNoteForm.dataset.section, key, { withNote: true, viaTimer: source === "timer" });
          return;
        }

        if (mode === "complete") {
          markHabitComplete(habit, key, { withNote: true, viaTimer: source === "timer" });
          return;
        }

        recordLiveStatus(`یادداشت ${habit.name} ویرایش شد`, "edit", "habits");
        saveState();
        showToast("یادداشت به روز شد.");
        render();
      });
    }

    document.querySelectorAll("[data-recovery-form]").forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        const habit = findHabit(form.dataset.habit);
        const type = form.dataset.recoveryType;
        const text = String(new FormData(form).get("recoveryText") || "").trim();
        if (!habit || !text) return;
        if (type === "impulsive") habit.impulsiveText = text;
        if (type === "cost") habit.costBenefitText = text;
        editingRecovery = null;
        recordLiveStatus(`متن بازگشت به «${habit.name}» ذخیره شد`, "edit", "today");
        saveState();
        showToast("متن ذخیره شد.");
        render();
      });
    });

    const importFile = document.getElementById("importFile");
    if (importFile) {
      importFile.addEventListener("change", handleImport);
    }

    const cloudRestoreForm = document.getElementById("cloudRestoreForm");
    if (cloudRestoreForm) {
      cloudRestoreForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const code = String(new FormData(cloudRestoreForm).get("recoveryCode") || "").trim();
        if (!parseCloudRecoveryCode(code)) {
          showToast("کد بازیابی معتبر نیست.", "error");
          return;
        }
        if (!confirm("اطلاعات فعلی با بکاپ ابری جایگزین شود؟")) return;

        const button = cloudRestoreForm.querySelector('button[type="submit"]');
        if (button) button.disabled = true;
        try {
          const restored = await restoreEncryptedCloudBackup(code);
          state = restored.state;
          cloudBackup = {
            ...restored.credentials,
            enabled: true,
            lastBackupAt: restored.updatedAt,
            lastErrorAt: null
          };
          saveCloudBackupCredentials();
          applyAppearance();
          recordLiveStatus("اطلاعات از بکاپ رمزگذاری‌شده بازیابی شد", "status", "today");
          saveState();
          queueReminderScheduleSync();
          currentView = "today";
          selectedDateKey = todayKey();
          calendarMonth = jalaliMonthKey(selectedDateKey);
          reportDayKey = todayKey();
          reportWeekKey = startOfWeekKey(todayKey());
          reportMonthKey = jalaliMonthKey(todayKey());
          showToast("بکاپ ابری بازیابی شد.");
          render();
        } catch {
          showToast("بکاپ پیدا نشد یا کد نادرست است.", "error");
          if (button) button.disabled = false;
        }
      });
    }

    const notificationForm = document.getElementById("notificationSettingsForm");
    if (notificationForm) {
      notificationForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const data = new FormData(notificationForm);
        state.notifications.statusTime = normalizeNotificationSettings({
          statusTime: data.get("statusTime")
        }).statusTime;
        state.notifications.rewardTime = normalizeNotificationSettings({
          rewardTime: data.get("rewardTime")
        }).rewardTime;
        await saveNotificationSchedule();
      });
    }
  }

  app.addEventListener("click", async (event) => {
    const target = event.target.closest("button");
    if (!target) return;

    if (target.dataset.closeHabitNote !== undefined) {
      editingHabitNote = null;
      render();
      return;
    }

    if (target.dataset.appearanceTheme) {
      state.appearance.theme = ["system", "dark", "deep"].includes(target.dataset.appearanceTheme)
        ? target.dataset.appearanceTheme
        : "system";
      applyAppearance();
      saveState();
      render();
      return;
    }

    if (target.dataset.appearanceText) {
      state.appearance.textSize = ["small", "normal", "large"].includes(target.dataset.appearanceText)
        ? target.dataset.appearanceText
        : "normal";
      applyAppearance();
      saveState();
      render();
      return;
    }

    if (target.dataset.toggleCloudBackup !== undefined) {
      if (cloudBackup.enabled) {
        cloudBackup.enabled = false;
        saveCloudBackupCredentials();
        showToast("بکاپ خودکار خاموش شد.");
        render();
        return;
      }
      if (!supportsCloudBackup()) {
        showToast("بکاپ ابری در این حالت در دسترس نیست.", "error");
        return;
      }
      if (!cloudBackup.id || !cloudBackup.key) {
        cloudBackup.id = randomBase64Url(24);
        cloudBackup.key = randomBase64Url(32);
      }
      cloudBackup.enabled = true;
      cloudBackup.lastErrorAt = null;
      saveCloudBackupCredentials();
      render();
      await uploadEncryptedCloudBackup(true);
      if (currentView === "reports") render();
      return;
    }

    if (target.dataset.backupNow !== undefined) {
      await uploadEncryptedCloudBackup(true);
      if (currentView === "reports") render();
      return;
    }

    if (target.dataset.copyRecovery !== undefined) {
      const code = cloudRecoveryCode();
      if (!code) return;
      try {
        await navigator.clipboard.writeText(code);
        showToast("کد بازیابی کپی شد.");
      } catch {
        const field = document.getElementById("cloudRecoveryCode");
        field?.select();
        showToast("کد را انتخاب و کپی کن.");
      }
      return;
    }

    if (target.dataset.exportRecovery !== undefined) {
      exportRecoveryCode();
      return;
    }

    if (target.dataset.deleteCloudBackup !== undefined) {
      if (!cloudBackup.id || !confirm("بکاپ ابری و کد بازیابی آن برای همیشه حذف شود؟")) return;
      try {
        await cloudBackupRequest(cloudBackup.id, { method: "DELETE" });
        cloudBackup = normalizeCloudBackupCredentials({});
        saveCloudBackupCredentials();
        showToast("بکاپ ابری حذف شد.");
        render();
      } catch {
        showToast("حذف بکاپ ابری انجام نشد.", "error");
      }
      return;
    }

    if (target.dataset.habitLibraryView) {
      habitLibraryView = ["habits", "notes", "recovery"].includes(target.dataset.habitLibraryView)
        ? target.dataset.habitLibraryView
        : "habits";
      if (habitLibraryView !== "habits") reorderMode = false;
      expandedHabitIds.clear();
      render();
      return;
    }

    if (target.dataset.toggleReorder !== undefined) {
      reorderMode = !reorderMode;
      expandedHabitIds.clear();
      render();
      return;
    }

    if (target.dataset.reorderMove) {
      const id = target.dataset.habit;
      const index = state.habits.findIndex((habit) => habit.id === id);
      const move = target.dataset.reorderMove;
      const nextIndex =
        move === "first" ? 0 : move === "last" ? state.habits.length - 1 : move === "up" ? index - 1 : index + 1;
      if (moveHabitToIndex(id, nextIndex)) render();
      return;
    }

    if (target.dataset.editHabitNote) {
      const habit = findHabit(target.dataset.editHabitNote);
      if (habit?.notes?.[target.dataset.date]) {
        openHabitNote(habit, target.dataset.date, "edit");
      }
      return;
    }

    if (target.dataset.deleteHabitNote) {
      const habit = findHabit(target.dataset.deleteHabitNote);
      const key = target.dataset.date;
      if (
        habit?.notes?.[key] &&
        confirm("با حذف این یادداشت، تیک همین عادت در این روز نیز برداشته می‌شود. ادامه می‌دهی؟")
      ) {
        const removedNote = { ...habit.notes[key] };
        const wasCompleted = Boolean(habit.completions?.[key]);
        const removedSectionCompletions = { ...(habit.sectionCompletions?.[key] || {}) };
        const habitId = habit.id;
        delete habit.notes[key];
        if (habit.completions?.[key]) delete habit.completions[key];
        if (isSectionedHabit(habit)) delete habit.sectionCompletions?.[key];
        recordLiveStatus(`یادداشت ${habit.name} برای ${formatJalaliShort(key)} حذف شد`, "edit", "habits");
        saveState();
        render();
        showUndoToast("یادداشت حذف شد.", () => {
          const currentHabit = findHabit(habitId);
          if (!currentHabit) return;
          currentHabit.notes ||= {};
          currentHabit.notes[key] = removedNote;
          if (wasCompleted) {
            currentHabit.completions ||= {};
            currentHabit.completions[key] = true;
          }
          if (Object.keys(removedSectionCompletions).length) {
            currentHabit.sectionCompletions ||= {};
            currentHabit.sectionCompletions[key] = { ...removedSectionCompletions };
          }
          recordLiveStatus(`یادداشت ${currentHabit.name} بازگردانده شد`, "edit", "habits");
          saveState();
          render();
        });
      }
      return;
    }

    if (target.dataset.toggleNotifications !== undefined) {
      if (state.notifications.enabled && "Notification" in window && Notification.permission === "granted") {
        await disableDailyNotifications();
      } else {
        await enableDailyNotifications();
      }
      return;
    }

    if (target.dataset.testNotification !== undefined) {
      await showNotificationPreview();
      return;
    }

    if (target.dataset.enableHabitSections !== undefined) {
      setHabitSectionMode(target.closest("form"), true);
      return;
    }

    if (target.dataset.disableHabitSections !== undefined) {
      const form = target.closest("form");
      const count = form?.querySelectorAll("[data-habit-section-row]").length || 0;
      if (count && !confirm("بخش‌ها حذف و عادت دوباره تک‌مرحله‌ای شود؟")) return;
      setHabitSectionMode(form, false);
      return;
    }

    if (target.dataset.addHabitSection !== undefined) {
      addHabitSectionRow(target);
      return;
    }

    if (target.dataset.removeHabitSection !== undefined) {
      const row = target.closest("[data-habit-section-row]");
      const list = row?.parentElement;
      const count = list?.querySelectorAll("[data-habit-section-row]").length || 0;
      if (count <= 2) {
        showToast("برای حذف همه بخش‌ها از «بازگشت به یک عادت» استفاده کن.", "error");
        return;
      }
      row.remove();
      return;
    }

    if (target.dataset.formNext) {
      moveFormStep(target.dataset.formNext, 1);
      return;
    }

    if (target.dataset.formPrev) {
      moveFormStep(target.dataset.formPrev, -1);
      return;
    }

    if (target.dataset.rewardFilter) {
      rewardFilter = target.dataset.rewardFilter;
      render();
      return;
    }

    if (target.dataset.toggleCompleted !== undefined) {
      completedHabitsCollapsed = !completedHabitsCollapsed;
      render();
      return;
    }

    if (target.dataset.toggleCompletedTasks !== undefined) {
      completedTasksCollapsed = !completedTasksCollapsed;
      render();
      return;
    }

    if (target.dataset.toggleReportDetails !== undefined) {
      reportDetailsExpanded = !reportDetailsExpanded;
      render();
      return;
    }

    if (target.dataset.toggleHabitDetails) {
      const habitId = target.dataset.toggleHabitDetails;
      if (expandedHabitIds.has(habitId)) expandedHabitIds.delete(habitId);
      else {
        expandedHabitIds.clear();
        expandedHabitIds.add(habitId);
      }
      render();
      return;
    }

    if (target.dataset.nav) {
      const nextView = target.dataset.nav;
      if (nextView === "add" && currentView !== "add") habitFormStep = 1;
      expandedHabitIds.clear();
      reorderMode = false;
      currentView = nextView;
      if (currentView === "today") {
        selectedDateKey = todayKey();
        calendarMonth = jalaliMonthKey(selectedDateKey);
      }
      if (currentView !== "edit") editingHabitId = null;
      editingRecovery = null;
      editingHabitNote = null;
      calendarOpen = false;
      render();
      return;
    }

    if (target.dataset.openCalendar !== undefined) {
      calendarContext = target.dataset.openCalendar || "schedule";
      const key = calendarContext === "report" ? reportDayKey : selectedDateKey;
      calendarMonth = jalaliMonthKey(key);
      calendarOpen = true;
      render();
      return;
    }

    if (target.dataset.closeCalendar !== undefined) {
      calendarOpen = false;
      render();
      return;
    }

    if (target.dataset.dateStep) {
      selectedDateKey = addDaysKey(selectedDateKey, Number(target.dataset.dateStep));
      expandedHabitIds.clear();
      completedHabitsCollapsed = true;
      completedTasksCollapsed = true;
      calendarMonth = jalaliMonthKey(selectedDateKey);
      calendarOpen = false;
      render();
      return;
    }

    if (target.dataset.calendarMonthStep) {
      const candidate = shiftJalaliMonthKey(calendarMonth, Number(target.dataset.calendarMonthStep));
      if (calendarContext !== "report" || candidate <= jalaliMonthKey(todayKey())) calendarMonth = candidate;
      render();
      return;
    }

    if (target.dataset.selectDate) {
      if (calendarContext === "report") {
        if (target.dataset.selectDate <= todayKey()) reportDayKey = target.dataset.selectDate;
        reportDetailsExpanded = false;
        calendarMonth = jalaliMonthKey(reportDayKey);
      } else {
        selectedDateKey = target.dataset.selectDate;
        expandedHabitIds.clear();
        completedHabitsCollapsed = true;
        completedTasksCollapsed = true;
        calendarMonth = jalaliMonthKey(selectedDateKey);
      }
      calendarOpen = false;
      render();
      return;
    }

    if (target.dataset.goToday !== undefined) {
      const context = target.dataset.goToday || calendarContext;
      if (context === "report") {
        reportDayKey = todayKey();
        reportDetailsExpanded = false;
        calendarMonth = jalaliMonthKey(reportDayKey);
      } else {
        selectedDateKey = todayKey();
        expandedHabitIds.clear();
        completedHabitsCollapsed = true;
        completedTasksCollapsed = true;
        calendarMonth = jalaliMonthKey(selectedDateKey);
      }
      calendarOpen = false;
      render();
      return;
    }

    if (target.dataset.reportPeriod) {
      reportPeriod = target.dataset.reportPeriod;
      reportDetailsExpanded = false;
      render();
      return;
    }

    if (target.dataset.reportStep) {
      const amount = Number(target.dataset.reportStep);
      reportDetailsExpanded = false;
      if (reportPeriod === "day") {
        const candidate = addDaysKey(reportDayKey, amount);
        reportDayKey = candidate > todayKey() ? todayKey() : candidate;
      } else if (reportPeriod === "month") {
        const candidate = shiftJalaliMonthKey(reportMonthKey, amount);
        reportMonthKey = candidate > jalaliMonthKey(todayKey()) ? jalaliMonthKey(todayKey()) : candidate;
      } else {
        const candidate = addDaysKey(reportWeekKey, amount * 7);
        const currentWeek = startOfWeekKey(todayKey());
        reportWeekKey = candidate > currentWeek ? currentWeek : candidate;
      }
      render();
      return;
    }

    if (target.dataset.reportCurrent !== undefined) {
      reportDetailsExpanded = false;
      if (reportPeriod === "day") reportDayKey = todayKey();
      if (reportPeriod === "week") reportWeekKey = startOfWeekKey(todayKey());
      if (reportPeriod === "month") reportMonthKey = jalaliMonthKey(todayKey());
      render();
      return;
    }

    if (target.dataset.formType) {
      habitFormType = target.dataset.formType;
      habitFormStep = 1;
      render();
      return;
    }

    if (target.dataset.focusTask !== undefined) {
      const input = document.getElementById("taskInput");
      if (input) input.focus();
      return;
    }

    if (target.dataset.toggleTask) {
      const key = target.dataset.date || todayKey();
      if (key > todayKey()) return;
      const task = tasksForDate(key).find((item) => item.id === target.dataset.toggleTask);
      if (task) {
        task.done = !task.done;
        if (task.done) completedTasksCollapsed = true;
        const dateSuffix = key === todayKey() ? "" : ` برای ${formatJalaliShort(key)}`;
        recordLiveStatus(
          task.done ? `کار «${task.text}» انجام شد${dateSuffix}` : `تیک کار «${task.text}» برداشته شد${dateSuffix}`,
          "task",
          "today"
        );
        saveState();
        queueReminderScheduleSync();
        render();
      }
      return;
    }

    if (target.dataset.deleteTask) {
      const key = target.dataset.date || todayKey();
      if (key < todayKey()) return;
      const rows = tasksForDate(key);
      const index = rows.findIndex((item) => item.id === target.dataset.deleteTask);
      const task = rows[index];
      state.tasks[key] = tasksForDate(key).filter((task) => task.id !== target.dataset.deleteTask);
      if (task) recordLiveStatus(`کار «${task.text}» حذف شد`, "task", "today");
      saveState();
      queueReminderScheduleSync();
      render();
      if (task) {
        showUndoToast("کار حذف شد.", () => {
          state.tasks[key] ||= [];
          if (!state.tasks[key].some((item) => item.id === task.id)) {
            state.tasks[key].splice(Math.max(0, index), 0, task);
          }
          recordLiveStatus(`کار «${task.text}» بازگردانده شد`, "task", "today");
          saveState();
          queueReminderScheduleSync();
          render();
        });
      }
      return;
    }

    if (target.dataset.toggleHabit) {
      toggleHabit(target.dataset.toggleHabit, target.dataset.date || todayKey());
      return;
    }

    if (target.dataset.toggleHabitSection) {
      toggleHabitSection(target.dataset.toggleHabitSection, target.dataset.section, target.dataset.date || todayKey());
      return;
    }

    if (target.dataset.startTimer) {
      startHabitTimer(target.dataset.startTimer, target.dataset.section || null);
      return;
    }

    if (target.dataset.toggleFocus !== undefined) {
      document.body.classList.toggle("focus-mode");
      target.setAttribute("aria-pressed", document.body.classList.contains("focus-mode") ? "true" : "false");
      return;
    }

    if (target.dataset.cancelTimer !== undefined) {
      document.body.classList.remove("focus-mode");
      cancelHabitTimer();
      return;
    }

    if (target.dataset.editHabit) {
      editingHabitId = target.dataset.editHabit;
      editFormStep = 1;
      habitLibraryView = "habits";
      currentView = "edit";
      render();
      return;
    }

    if (target.dataset.deleteHabit) {
      const habit = findHabit(target.dataset.deleteHabit);
      if (habit && confirm(`عادت «${habit.name}» حذف شود؟`)) {
        const index = state.habits.findIndex((item) => item.id === habit.id);
        const removedTimer = state.activeTimer?.habitId === habit.id ? { ...state.activeTimer } : null;
        const wasExpanded = expandedHabitIds.has(habit.id);
        if (state.activeTimer?.habitId === habit.id) state.activeTimer = null;
        state.habits = state.habits.filter((item) => item.id !== habit.id);
        persistHabitOrder();
        expandedHabitIds.delete(habit.id);
        recordLiveStatus(`عادت «${habit.name}» حذف شد`, "edit", "habits");
        saveState();
        queueReminderScheduleSync();
        render();
        showUndoToast(`عادت ${habit.name} حذف شد.`, () => {
          if (!state.habits.some((item) => item.id === habit.id)) {
            state.habits.splice(Math.max(0, index), 0, habit);
          }
          persistHabitOrder();
          if (removedTimer && !state.activeTimer) state.activeTimer = removedTimer;
          if (wasExpanded) expandedHabitIds.add(habit.id);
          recordLiveStatus(`عادت «${habit.name}» بازگردانده شد`, "edit", "habits");
          saveState();
          queueReminderScheduleSync();
          render();
        });
      }
      return;
    }

    if (target.dataset.editRecovery) {
      editingRecovery = {
        habitId: target.dataset.habit,
        type: target.dataset.editRecovery
      };
      render();
      return;
    }

    if (target.dataset.cancelRecoveryEdit !== undefined) {
      editingRecovery = null;
      render();
      return;
    }

    if (target.dataset.recovery) {
      const habit = findHabit(target.dataset.habit);
      if (habit) {
        habit.recovery ||= {};
        if (target.dataset.recovery === "impulsive") habit.recovery.impulsiveDoneAt = todayKey();
        if (target.dataset.recovery === "cost") habit.recovery.costDoneAt = todayKey();
        editingRecovery = null;
        recordLiveStatus(`مرحله بازگشت به «${habit.name}» انجام شد`, "habit", "today");
        saveState();
        showToast("ثبت شد.");
        render();
      }
      return;
    }

    if (target.dataset.duration) {
      const habit = findHabit(target.dataset.habit);
      if (habit) {
        habit.durationSuggestion ||= {};
        habit.durationSuggestion.lastWeek = startOfWeekKey(todayKey());
        if (target.dataset.duration === "accept") {
          habit.duration = Number(habit.duration || 0) + 5;
          recordLiveStatus(`زمان «${habit.name}» به ${toFa(habit.duration)} دقیقه افزایش یافت`, "edit", "habits");
          showToast("۵ دقیقه اضافه شد.");
        } else {
          showToast("برای این هفته رد شد.");
        }
        saveState();
        render();
      }
      return;
    }

    if (target.dataset.claimReward) {
      const habit = findHabit(target.dataset.habit);
      const reward = habit?.rewardLedger.find((item) => item.id === target.dataset.claimReward);
      if (reward && !reward.claimedAt) {
        reward.claimedAt = todayKey();
        recordLiveStatus(`پاداش «${reward.title}» گرفته شد`, "reward", "rewards");
        saveState();
        render();
        const habitId = habit.id;
        const rewardId = reward.id;
        showUndoToast("پاداش گرفته‌شده ثبت شد.", () => {
          const currentReward = findHabit(habitId)?.rewardLedger.find((item) => item.id === rewardId);
          if (!currentReward) return;
          currentReward.claimedAt = null;
          recordLiveStatus(`دریافت پاداش «${currentReward.title}» بازگردانده شد`, "reward", "rewards");
          saveState();
          render();
        });
      }
      return;
    }

    if (target.dataset.export !== undefined) {
      exportBackup();
      return;
    }

    if (target.dataset.importTrigger !== undefined) {
      document.getElementById("importFile")?.click();
    }
  });

  function finishReorderDrag() {
    const drag = reorderDrag;
    reorderDrag = null;
    clearReorderDragMarks();
    if (!drag?.targetId || drag.targetId === drag.id) return;
    if (moveHabitRelative(drag.id, drag.targetId, drag.before)) render();
  }

  app.addEventListener("pointerdown", (event) => {
    if (!reorderMode) return;
    const handle = event.target.closest?.("[data-reorder-handle]");
    if (!handle) return;
    const card = handle.closest("[data-reorder-card]");
    if (!card) return;
    reorderDrag = { id: card.dataset.reorderCard, targetId: null, before: true };
    card.classList.add("reorder-dragging");
    handle.setPointerCapture?.(event.pointerId);
    event.preventDefault();
  });

  app.addEventListener("pointermove", (event) => {
    if (!reorderDrag) return;
    const element = document.elementFromPoint?.(event.clientX, event.clientY);
    const card = element?.closest?.("[data-reorder-card]");
    clearReorderDragMarks();
    if (!card || card.dataset.reorderCard === reorderDrag.id) {
      const dragged = document.querySelector(`[data-reorder-card="${reorderDrag.id}"]`);
      dragged?.classList.add("reorder-dragging");
      reorderDrag.targetId = null;
      return;
    }
    const box = card.getBoundingClientRect();
    reorderDrag.targetId = card.dataset.reorderCard;
    reorderDrag.before = event.clientY < box.top + box.height / 2;
    card.classList.add(reorderDrag.before ? "reorder-drop-before" : "reorder-drop-after");
    document.querySelector(`[data-reorder-card="${reorderDrag.id}"]`)?.classList.add("reorder-dragging");
  });

  app.addEventListener("pointerup", finishReorderDrag);
  app.addEventListener("pointercancel", () => {
    reorderDrag = null;
    clearReorderDragMarks();
  });

  function toggleHabit(id, key = todayKey()) {
    const habit = findHabit(id);
    if (!habit || key > todayKey() || !isScheduledOn(habit, key)) return;
    if (isSectionedHabit(habit)) return;
    if (isDone(habit, key)) {
      clearHabitCompletion(habit, key);
      return;
    }
    if (habit.noteEnabled) {
      openHabitNote(habit, key, "complete");
      return;
    }
    markHabitComplete(habit, key);
  }

  function toggleHabitSection(id, sectionId, key = todayKey()) {
    const habit = findHabit(id);
    if (!habit || !isSectionedHabit(habit) || key > todayKey() || !isScheduledOn(habit, key)) return;
    if (isSectionDone(habit, sectionId, key)) {
      clearHabitSectionCompletion(habit, sectionId, key);
      return;
    }
    completeHabitSection(habit, sectionId, key);
  }

  function exportBackup() {
    state.lastBackupAt = new Date().toISOString();
    saveState();
    const payload = {
      exportedAt: state.lastBackupAt,
      app: "fa-habit-tracker",
      data: state
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `habit-backup-${todayKey()}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    showToast("فایل بکاپ ساخته شد.");
  }

  function exportRecoveryCode() {
    const code = cloudRecoveryCode();
    if (!code) return;
    const blob = new Blob([code], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `habit-recovery-code-${todayKey()}.txt`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    showToast("فایل کد بازیابی ساخته شد.");
  }

  function handleImport(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result || "{}"));
        const imported = parsed.data || parsed;
        state = normalizeState(imported);
        recordLiveStatus("اطلاعات از نسخه پشتیبان بازیابی شد", "status", "today");
        saveState();
        queueReminderScheduleSync();
        currentView = "today";
        selectedDateKey = todayKey();
        calendarMonth = jalaliMonthKey(selectedDateKey);
        calendarOpen = false;
        reportDayKey = todayKey();
        reportWeekKey = startOfWeekKey(todayKey());
        reportMonthKey = jalaliMonthKey(todayKey());
        showToast("اطلاعات بازیابی شد.");
        render();
      } catch (error) {
        showToast("فایل بکاپ قابل خواندن نیست.", "error");
      }
    };
    reader.readAsText(file);
  }

  function showToast(message, type = "info") {
    clearTimeout(toastTimer);
    const old = document.querySelector(".toast");
    if (old) old.remove();
    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.setAttribute("role", type === "error" ? "alert" : "status");
    toast.setAttribute("aria-live", type === "error" ? "assertive" : "polite");
    toast.textContent = message;
    document.body.appendChild(toast);
    toastTimer = setTimeout(() => toast.remove(), 2400);
  }

  function showUndoToast(message, undo) {
    clearTimeout(toastTimer);
    document.querySelector(".toast")?.remove();
    const toast = document.createElement("div");
    toast.className = "toast undo-toast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");

    const text = document.createElement("span");
    text.textContent = message;
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "بازگردانی";
    button.addEventListener("click", () => {
      clearTimeout(toastTimer);
      toast.remove();
      undo();
      showToast("بازگردانده شد.");
    });
    toast.append(text, button);
    document.body.appendChild(toast);
    toastTimer = setTimeout(() => toast.remove(), 8000);
  }

  async function initializeServiceWorker() {
    if (!("serviceWorker" in navigator)) return;
    try {
      const registration = await navigator.serviceWorker.register("./sw.js");
      await registration.update().catch(() => {});
      await writeNotificationSnapshot().catch(() => {});
      await updateAppBadge().catch(() => {});
      syncNativeWidget();

      if (state.notifications.enabled && "Notification" in window && Notification.permission === "granted") {
        const subscription = await registration.pushManager?.getSubscription();
        if (subscription) {
          await registerPushSchedule(subscription);
          state.notifications.serverConnected = true;
          localStorage.setItem(STORE_KEY, JSON.stringify(state));
        }
        await updatePersistentStatusNotification().catch(() => {});
      }
    } catch (error) {
      if (state.notifications.enabled) {
        state.notifications.serverConnected = false;
        localStorage.setItem(STORE_KEY, JSON.stringify(state));
      }
    }
  }

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", initializeServiceWorker);
    navigator.serviceWorker.addEventListener("message", (event) => {
      if (event.data?.type !== "NAVIGATE") return;
      const view = event.data.view;
      if (!["today", "habits", "rewards", "reports"].includes(view)) return;
      currentView = view;
      calendarOpen = false;
      if (view === "today") {
        selectedDateKey = todayKey();
        calendarMonth = jalaliMonthKey(selectedDateKey);
      }
      render();
    });
  }

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      updateTimerDisplay();
      queueNotificationStateSync();
      updatePersistentStatusNotification().catch(() => {});
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && editingHabitNote) {
      editingHabitNote = null;
      render();
      return;
    }
    if (event.key === "Escape" && calendarOpen) {
      calendarOpen = false;
      render();
    }
  });
  window.addEventListener("focus", updateTimerDisplay);
  window.addEventListener("offline", () => showToast("برنامه آفلاین است؛ اطلاعات روی گوشی محفوظ می‌ماند."));
  window.addEventListener("online", () => {
    showToast("اتصال دوباره برقرار شد.");
    queueCloudBackup();
  });

  const colorSchemeQuery = window.matchMedia?.("(prefers-color-scheme: dark)");
  const handleColorSchemeChange = () => {
    if (state.appearance.theme === "system") applyAppearance();
  };
  if (colorSchemeQuery?.addEventListener) {
    colorSchemeQuery.addEventListener("change", handleColorSchemeChange);
  } else {
    colorSchemeQuery?.addListener?.(handleColorSchemeChange);
  }

  applyAppearance();
  render();
  if (requestedView) {
    window.history.replaceState({}, "", `${window.location.pathname}${window.location.hash}`);
  }
})();
