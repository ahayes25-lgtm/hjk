import { getStore } from "@netlify/blobs";
import webpush from "web-push";
import { getVapidConfig, SUBSCRIPTION_STORE } from "./_push-store.mjs";

function localClock(now, timeZone) {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-CA", {
      timeZone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23"
    })
      .formatToParts(now)
      .filter((part) => part.type !== "literal")
      .map((part) => [part.type, part.value])
  );
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    minutes: Number(parts.hour) * 60 + Number(parts.minute),
    weekDay: (new Date(Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day))).getUTCDay() + 1) % 7
  };
}

function timeMinutes(value) {
  const [hour, minute] = value.split(":").map(Number);
  return hour * 60 + minute;
}

function isDue(currentMinutes, targetTime, lastDate, localDate) {
  const targetMinutes = timeMinutes(targetTime);
  return lastDate !== localDate && currentMinutes >= targetMinutes && currentMinutes < targetMinutes + 3;
}

async function send(webpushClient, record, type, date, options = {}) {
  await webpushClient.sendNotification(
    record.subscription,
    JSON.stringify({ type, date, time: options.time || "", sound: options.sound !== false }),
    {
      TTL: 60 * 60,
      urgency: "normal"
    }
  );
}

export default async () => {
  const subscriptions = getStore(SUBSCRIPTION_STORE);
  const { blobs } = await subscriptions.list({ prefix: "subscription-" });
  if (!blobs.length) return new Response(null, { status: 204 });

  const vapid = await getVapidConfig();
  webpush.setVapidDetails(vapid.subject, vapid.publicKey, vapid.privateKey);
  const now = new Date();

  for (const blob of blobs) {
    const record = await subscriptions.get(blob.key, { type: "json", consistency: "strong" });
    if (!record?.subscription || !record?.timeZone) continue;

    try {
      const clock = localClock(now, record.timeZone);
      let changed = false;

      if (isDue(clock.minutes, record.statusTime, record.lastStatusDate, clock.date)) {
        await send(webpush, record, "status", clock.date);
        record.lastStatusDate = clock.date;
        changed = true;
      }

      if (isDue(clock.minutes, record.rewardTime, record.lastRewardDate, clock.date)) {
        await send(webpush, record, "rewards", clock.date);
        record.lastRewardDate = clock.date;
        changed = true;
      }

      const reminderDates =
        record.lastReminderDates && typeof record.lastReminderDates === "object" && !Array.isArray(record.lastReminderDates)
          ? record.lastReminderDates
          : {};
      for (const reminder of Array.isArray(record.reminders) ? record.reminders : []) {
        if (!Array.isArray(reminder?.days) || !reminder.days.includes(clock.weekDay)) continue;
        if (!isDue(clock.minutes, reminder.time, reminderDates[reminder.time], clock.date)) continue;
        await send(webpush, record, "reminder", clock.date, { time: reminder.time, sound: reminder.sound !== false });
        reminderDates[reminder.time] = clock.date;
        changed = true;
      }
      record.lastReminderDates = reminderDates;

      const taskReminderDates =
        record.lastTaskReminderDates && typeof record.lastTaskReminderDates === "object" && !Array.isArray(record.lastTaskReminderDates)
          ? record.lastTaskReminderDates
          : {};
      for (const reminder of Array.isArray(record.taskReminders) ? record.taskReminders : []) {
        if (reminder?.date !== clock.date) continue;
        const reminderKey = `${reminder.date}|${reminder.time}`;
        if (!isDue(clock.minutes, reminder.time, taskReminderDates[reminderKey], clock.date)) continue;
        await send(webpush, record, "task", clock.date, { time: reminder.time, sound: reminder.sound !== false });
        taskReminderDates[reminderKey] = clock.date;
        changed = true;
      }
      record.lastTaskReminderDates = taskReminderDates;

      if (changed) {
        record.updatedAt = new Date().toISOString();
        await subscriptions.setJSON(blob.key, record);
      }
    } catch (error) {
      if (error?.statusCode === 404 || error?.statusCode === 410) {
        await subscriptions.delete(blob.key);
      }
    }
  }

  return new Response(null, { status: 204 });
};
