const CACHE_NAME = "habit-tracker-fa-v17";
const NOTIFICATION_DB_NAME = "fa-habit-tracker-notifications";
const NOTIFICATION_STORE_NAME = "local-state";
const LIVE_STATUS_TAG = "habit-tracker-live-status";
const ASSETS = [
  "./",
  "./index.html",
  "./styles.css",
  "./app.js",
  "./manifest.webmanifest",
  "./app-icon-192.png",
  "./app-icon-512.png",
  "./apple-touch-icon.png",
  "./apple-splash-1320x2868.png",
  "./apple-splash-dark-1320x2868.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.pathname.startsWith("/.netlify/functions/")) return;
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request).catch(() => caches.match("./index.html")))
  );
});

function openNotificationDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(NOTIFICATION_DB_NAME, 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(NOTIFICATION_STORE_NAME)) {
        database.createObjectStore(NOTIFICATION_STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Could not open notification storage"));
  });
}

async function readNotificationSnapshot() {
  const database = await openNotificationDatabase();
  const snapshot = await new Promise((resolve, reject) => {
    const transaction = database.transaction(NOTIFICATION_STORE_NAME, "readonly");
    const request = transaction.objectStore(NOTIFICATION_STORE_NAME).get("snapshot");
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error("Could not read notification state"));
  });
  database.close();
  return snapshot;
}

function faNumber(value) {
  return new Intl.NumberFormat("fa-IR").format(Number(value || 0));
}

function localDateKey(date = new Date()) {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-CA", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    })
      .formatToParts(date)
      .filter((part) => part.type !== "literal")
      .map((part) => [part.type, part.value])
  );
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function weekIndexFromKey(key) {
  const [year, month, day] = key.split("-").map(Number);
  return (new Date(Date.UTC(year, month - 1, day)).getUTCDay() + 1) % 7;
}

function habitScheduledOn(habit, key) {
  if (!habit?.createdAt || key < habit.createdAt) return false;
  if (habit.type === "new" && !habit.graduatedAt) return true;
  const schedule = Array.isArray(habit.schedule) ? habit.schedule : [0, 1, 2, 3, 4, 5, 6];
  return schedule.includes(weekIndexFromKey(key));
}

function progressForDate(snapshot, key) {
  if (snapshot?.dateKey === key && snapshot?.progress) return snapshot.progress;
  const habits = (snapshot?.habits || []).filter((habit) => habitScheduledOn(habit, key));
  const habitDone = habits.filter((habit) => Boolean(habit.completions?.[key])).length;
  const tasks = Array.isArray(snapshot?.tasks?.[key]) ? snapshot.tasks[key] : [];
  const taskDone = tasks.filter((task) => Boolean(task.done)).length;
  return {
    habitTotal: habits.length,
    habitDone,
    habitPercent: habits.length ? Math.round((habitDone / habits.length) * 100) : 0,
    taskTotal: tasks.length,
    taskDone,
    remaining: Math.max(0, habits.length - habitDone) + Math.max(0, tasks.length - taskDone)
  };
}

function statusBody(snapshot, key) {
  if (!snapshot) return "درصد عادت‌ها و وضعیت کارهای امروز داخل برنامه آماده است.";
  const progress = progressForDate(snapshot, key);
  const readyRewards = Number(snapshot.rewards?.ready || 0);
  const lastChange = String(snapshot.liveStatus?.message || "").trim();
  const summary =
    `${faNumber(progress.habitPercent)}٪ عادت‌ها · ` +
    `${faNumber(progress.habitDone)} از ${faNumber(progress.habitTotal)} عادت · ` +
    `${faNumber(progress.taskDone)} از ${faNumber(progress.taskTotal)} کار · ` +
    `${faNumber(readyRewards)} پاداش آماده`;
  return lastChange ? `${summary}\n${lastChange}` : summary;
}

function rewardBody(snapshot, key) {
  if (!snapshot?.rewards) return "نتیجه پاداش‌های امروز داخل برنامه آماده است.";
  const unlockedToday = (snapshot.rewards.unlockedDates || []).filter((date) => date === key).length;
  const claimedToday = (snapshot.rewards.claimedDates || []).filter((date) => date === key).length;
  return `امروز ${faNumber(unlockedToday)} پاداش آزاد و ${faNumber(claimedToday)} پاداش گرفته شد؛ ${faNumber(snapshot.rewards.ready)} پاداش آماده دریافت است.`;
}

async function updateBadgeFromSnapshot(snapshot, key) {
  if (!snapshot || !("setAppBadge" in self.navigator)) return;
  const remaining = progressForDate(snapshot, key).remaining;
  if (remaining > 0) await self.navigator.setAppBadge(remaining);
  else if ("clearAppBadge" in self.navigator) await self.navigator.clearAppBadge();
}

self.addEventListener("push", (event) => {
  event.waitUntil(
    (async () => {
      let payload = {};
      try {
        payload = event.data?.json?.() || {};
      } catch {
        payload = {};
      }
      const type = ["rewards", "reminder", "task"].includes(payload.type) ? payload.type : "status";
      const key = /^\d{4}-\d{2}-\d{2}$/.test(payload.date || "") ? payload.date : localDateKey();
      const snapshot = await readNotificationSnapshot().catch(() => null);
      const isReward = type === "rewards";
      const isReminder = type === "reminder";
      const isTask = type === "task";
      await updateBadgeFromSnapshot(snapshot, key).catch(() => {});
      await self.registration.showNotification(
        isReward ? "نتیجه پاداش‌های امروز" : isReminder ? "یادآور عادت" : isTask ? "یادآور کار" : "وضعیت زنده امروز",
        {
          body: isReward ? rewardBody(snapshot, key) : isReminder ? "زمان انجام یک عادت رسیده است." : isTask ? "زمان انجام یک کار رسیده است." : statusBody(snapshot, key),
          icon: "./app-icon-192.png",
          badge: "./app-icon-192.png",
          tag: isReward ? `habit-tracker-rewards-${key}` : isReminder ? `habit-tracker-reminder-${key}-${payload.time || "now"}` : isTask ? `habit-tracker-task-${key}-${payload.time || "now"}` : LIVE_STATUS_TAG,
          renotify: isReminder || isTask,
          requireInteraction: !isReminder && !isTask,
          silent: (isReminder || isTask) && payload.sound !== true,
          dir: "rtl",
          lang: "fa",
          data: { view: isReward ? "rewards" : isReminder || isTask ? "today" : snapshot?.liveStatus?.view || "today" }
        }
      );
    })()
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const requestedView = event.notification.data?.view;
  const view = ["today", "habits", "rewards", "reports"].includes(requestedView) ? requestedView : "today";
  const targetUrl = new URL(`./index.html?view=${view}`, self.registration.scope).href;
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(async (clients) => {
      const appClient = clients.find((client) => client.url.startsWith(self.registration.scope));
      if (appClient) {
        appClient.postMessage({ type: "NAVIGATE", view });
        return appClient.focus();
      }
      return self.clients.openWindow(targetUrl);
    })
  );
});
