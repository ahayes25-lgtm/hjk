import { getVapidConfig, jsonResponse } from "./_push-store.mjs";

export default async (request) => {
  if (request.method !== "GET") return jsonResponse({ error: "Method not allowed" }, 405);
  try {
    const config = await getVapidConfig();
    return jsonResponse({ publicKey: config.publicKey });
  } catch {
    return jsonResponse({ error: "Push configuration is unavailable" }, 503);
  }
};

export const config = {
  rateLimit: {
    windowSize: 60,
    windowLimit: 30,
    aggregateBy: "ip"
  }
};
