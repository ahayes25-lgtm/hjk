import { getStore } from "@netlify/blobs";
import {
  SUBSCRIPTION_STORE,
  jsonResponse,
  sanitizeSubscription,
  sanitizeReminders,
  sanitizeTaskReminders,
  subscriptionKey,
  validTime,
  validTimeZone
} from "./_push-store.mjs";

async function parseJson(request) {
  const length = Number(request.headers.get("content-length") || 0);
  if (length > 12_000) throw new Error("Payload too large");
  return request.json();
}

export default async (request) => {
  const store = getStore(SUBSCRIPTION_STORE);

  if (request.method === "POST") {
    try {
      const payload = await parseJson(request);
      const subscription = sanitizeSubscription(payload.subscription);
      const statusTime = String(payload.statusTime || "");
      const rewardTime = String(payload.rewardTime || "");
      const timeZone = String(payload.timeZone || "");
      const reminders = sanitizeReminders(payload.reminders);
      const taskReminders = sanitizeTaskReminders(payload.taskReminders);
      if (!subscription || !validTime(statusTime) || !validTime(rewardTime) || !validTimeZone(timeZone)) {
        return jsonResponse({ error: "Invalid subscription settings" }, 400);
      }

      const key = subscriptionKey(subscription.endpoint);
      const previous = await store.get(key, { type: "json", consistency: "strong" });
      const taskReminderKeys = new Set(taskReminders.map((reminder) => `${reminder.date}|${reminder.time}`));
      const previousTaskReminderDates =
        previous?.lastTaskReminderDates && typeof previous.lastTaskReminderDates === "object" && !Array.isArray(previous.lastTaskReminderDates)
          ? previous.lastTaskReminderDates
          : {};
      await store.setJSON(key, {
        subscription,
        statusTime,
        rewardTime,
        reminders,
        taskReminders,
        timeZone,
        createdAt: previous?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        lastStatusDate: previous?.lastStatusDate || null,
        lastRewardDate: previous?.lastRewardDate || null,
        lastReminderDates:
          previous?.lastReminderDates && typeof previous.lastReminderDates === "object" && !Array.isArray(previous.lastReminderDates)
            ? previous.lastReminderDates
            : {},
        lastTaskReminderDates:
          Object.fromEntries(Object.entries(previousTaskReminderDates).filter(([reminderKey]) => taskReminderKeys.has(reminderKey)))
      });
      return jsonResponse({ ok: true });
    } catch {
      return jsonResponse({ error: "Could not save subscription" }, 400);
    }
  }

  if (request.method === "DELETE") {
    try {
      const payload = await parseJson(request);
      const endpoint = String(payload.endpoint || "");
      if (!endpoint.startsWith("https://") || endpoint.length > 4096) {
        return jsonResponse({ error: "Invalid endpoint" }, 400);
      }
      await store.delete(subscriptionKey(endpoint));
      return jsonResponse({ ok: true });
    } catch {
      return jsonResponse({ error: "Could not remove subscription" }, 400);
    }
  }

  return jsonResponse({ error: "Method not allowed" }, 405);
};

export const config = {
  rateLimit: {
    windowSize: 60,
    windowLimit: 20,
    aggregateBy: "ip"
  }
};
